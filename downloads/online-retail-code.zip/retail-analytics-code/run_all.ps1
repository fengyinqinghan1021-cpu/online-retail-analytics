$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

$python = if (Test-Path "D:\ancondas\python.exe") {
    "D:\ancondas\python.exe"
} else {
    "python"
}

Write-Host "==> 01 ingest" -ForegroundColor Cyan
& $python python/01_ingest.py
Write-Host "==> 02 SQL pipeline" -ForegroundColor Cyan
& $python python/02_sql_pipeline.py --full
Write-Host "==> 03 clean + EDA" -ForegroundColor Cyan
& $python python/03_clean_eda.py
Write-Host "==> 04 Excel dashboard" -ForegroundColor Cyan
& $python python/04_build_excel.py
Write-Host "==> 06 Power BI PBIP" -ForegroundColor Cyan
& $python python/06_build_powerbi.py
Write-Host "==> 07 validate PBIP" -ForegroundColor Cyan
& $python python/07_validate_powerbi.py
Write-Host "==> 08 project portal + report" -ForegroundColor Cyan
& $python python/08_build_portal.py

Write-Host ""
Write-Host "Done. Open index.html in a browser." -ForegroundColor Green
