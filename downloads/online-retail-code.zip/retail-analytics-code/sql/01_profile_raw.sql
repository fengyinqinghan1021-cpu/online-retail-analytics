-- @query: overview
SELECT
    COUNT(*) AS rows,
    COUNT(DISTINCT invoice) AS invoices,
    COUNT(DISTINCT stock_code) AS stock_codes,
    COUNT(DISTINCT customer_id) AS customers,
    COUNT(DISTINCT country) AS countries,
    MIN(invoice_date) AS first_invoice_ts,
    MAX(invoice_date) AS last_invoice_ts
FROM raw;

-- @query: column_profile
SELECT 'invoice' AS column_name, COUNT(*) - COUNT(invoice) AS null_rows,
       COUNT(DISTINCT invoice) AS distinct_values FROM raw
UNION ALL
SELECT 'stock_code', COUNT(*) - COUNT(stock_code), COUNT(DISTINCT stock_code) FROM raw
UNION ALL
SELECT 'description', COUNT(*) - COUNT(description), COUNT(DISTINCT description) FROM raw
UNION ALL
SELECT 'quantity', COUNT(*) - COUNT(quantity), COUNT(DISTINCT quantity) FROM raw
UNION ALL
SELECT 'invoice_date', COUNT(*) - COUNT(invoice_date), COUNT(DISTINCT invoice_date) FROM raw
UNION ALL
SELECT 'price', COUNT(*) - COUNT(price), COUNT(DISTINCT price) FROM raw
UNION ALL
SELECT 'customer_id', COUNT(*) - COUNT(customer_id), COUNT(DISTINCT customer_id) FROM raw
UNION ALL
SELECT 'country', COUNT(*) - COUNT(country), COUNT(DISTINCT country) FROM raw;

-- @query: duplicates
WITH grouped AS (
    SELECT
        invoice, stock_code, description, quantity, invoice_date,
        price, customer_id, country,
        COUNT(*) AS copies
    FROM raw
    GROUP BY ALL
)
SELECT
    SUM(CASE WHEN copies > 1 THEN copies - 1 ELSE 0 END) AS extra_duplicate_rows,
    COUNT(*) FILTER (WHERE copies > 1) AS duplicate_groups
FROM grouped;

-- @query: overlapping_period
SELECT
    source_sheet,
    COUNT(*) AS rows,
    COUNT(DISTINCT invoice) AS invoices,
    MIN(invoice_date) AS first_ts,
    MAX(invoice_date) AS last_ts
FROM raw
GROUP BY source_sheet
ORDER BY source_sheet;

-- @query: data_quality
SELECT
    COUNT(*) FILTER (WHERE invoice LIKE 'C%') AS cancellation_lines,
    COUNT(*) FILTER (WHERE quantity < 0) AS negative_quantity_lines,
    COUNT(*) FILTER (WHERE price <= 0) AS nonpositive_price_lines,
    COUNT(*) FILTER (WHERE customer_id IS NULL) AS missing_customer_lines,
    COUNT(*) FILTER (WHERE description IS NULL) AS missing_description_lines,
    COUNT(*) FILTER (WHERE invoice IS NULL OR stock_code IS NULL) AS missing_key_lines,
    ROUND(SUM(CASE WHEN quantity > 0 AND price > 0 AND invoice NOT LIKE 'C%'
                   THEN quantity * price ELSE 0 END), 2) AS gross_sales_value
FROM raw;

-- @query: nonstandard_stock_codes
SELECT
    stock_code,
    ANY_VALUE(description) AS example_description,
    COUNT(*) AS lines,
    ROUND(SUM(quantity * price), 2) AS net_amount
FROM raw
WHERE stock_code NOT SIMILAR TO '[0-9]{5}[A-Z]?'
GROUP BY stock_code
ORDER BY lines DESC;

-- @query: monthly_rows
SELECT
    DATE_TRUNC('month', invoice_date)::DATE AS month,
    source_sheet,
    COUNT(*) AS rows,
    COUNT(DISTINCT invoice) AS invoices
FROM raw
GROUP BY ALL
ORDER BY month, source_sheet;

-- @query: duplicates_by_sheet
WITH grouped AS (
    SELECT
        invoice, stock_code, description, quantity, invoice_date,
        price, customer_id, country,
        COUNT(*) AS copies,
        COUNT(DISTINCT source_sheet) AS source_sheets
    FROM raw
    GROUP BY ALL
)
SELECT
    source_sheets,
    COUNT(*) AS duplicate_groups,
    SUM(copies - 1) AS extra_rows
FROM grouped
WHERE copies > 1
GROUP BY source_sheets
ORDER BY source_sheets;

-- @query: duplicate_months
WITH grouped AS (
    SELECT
        invoice, stock_code, description, quantity, invoice_date,
        price, customer_id, country,
        COUNT(*) AS copies
    FROM raw
    GROUP BY ALL
)
SELECT
    DATE_TRUNC('month', invoice_date)::DATE AS month,
    COUNT(*) AS duplicate_groups,
    SUM(copies - 1) AS extra_rows
FROM grouped
WHERE copies > 1
GROUP BY 1
ORDER BY 1;
