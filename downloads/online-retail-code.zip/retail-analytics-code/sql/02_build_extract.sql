-- Build a typed, de-duplicated line-level extract.
-- Duplicate policy: remove only cross-sheet duplicates in the 2010-12 overlap.
-- Identical lines within the same sheet are retained because they may be legitimate.

CREATE OR REPLACE TABLE sales_extract AS
WITH normalized AS (
    SELECT
        invoice,
        UPPER(TRIM(stock_code)) AS stock_code,
        UPPER(TRIM(description)) AS description,
        quantity,
        invoice_date,
        price,
        customer_id,
        country,
        source_sheet
    FROM raw
),
ranked AS (
    SELECT
        *,
        COUNT(DISTINCT source_sheet) OVER (
            PARTITION BY invoice, stock_code, quantity, invoice_date,
                         price, customer_id, country
        ) AS source_sheet_count,
        ROW_NUMBER() OVER (
            PARTITION BY invoice, stock_code, quantity, invoice_date,
                         price, customer_id, country
            ORDER BY source_sheet DESC
        ) AS duplicate_rank
    FROM normalized
),
deduplicated AS (
    SELECT *
    FROM ranked
    WHERE NOT (source_sheet_count > 1 AND duplicate_rank > 1)
),
flagged AS (
    SELECT
        ROW_NUMBER() OVER (ORDER BY invoice_date, invoice, stock_code) AS line_id,
        invoice,
        stock_code,
        NULLIF(description, '') AS description,
        CAST(quantity AS INTEGER) AS quantity,
        invoice_date,
        CAST(price AS DOUBLE) AS price,
        customer_id,
        country,
        source_sheet,
        CAST(quantity AS DOUBLE) * CAST(price AS DOUBLE) AS gross_amount,
        invoice LIKE 'C%' AS is_cancellation,
        CAST(quantity AS INTEGER) < 0 AS is_negative_quantity,
        CAST(price AS DOUBLE) <= 0 AS is_nonpositive_price,
        (
            stock_code IN (
                'POST', 'DOT', 'M', 'C2', 'C3', 'D', 'S', 'B',
                'BANK CHARGES', 'AMAZONFEE', 'CRUK', 'PAD',
                'ADJUST', 'ADJUST2', 'TEST001', 'TEST002'
            )
            OR stock_code LIKE 'GIFT_0001_%'
        ) AS is_special_code,
        CAST(invoice_date AS DATE) AS invoice_date_key,
        DATE_TRUNC('month', invoice_date)::DATE AS invoice_month,
        EXTRACT(YEAR FROM invoice_date)::INTEGER AS invoice_year,
        EXTRACT(MONTH FROM invoice_date)::INTEGER AS invoice_month_num,
        EXTRACT(QUARTER FROM invoice_date)::INTEGER AS invoice_quarter,
        EXTRACT(ISODOW FROM invoice_date)::INTEGER AS invoice_weekday,
        EXTRACT(HOUR FROM invoice_date)::INTEGER AS invoice_hour
    FROM deduplicated
)
SELECT
    *,
    NOT is_cancellation
        AND quantity > 0
        AND price > 0
        AND NOT is_special_code AS is_product_sale,
    (is_cancellation OR quantity < 0)
        AND price > 0
        AND NOT is_special_code AS is_product_return,
    CASE
        WHEN NOT is_cancellation AND quantity > 0 AND price > 0 AND NOT is_special_code
        THEN quantity * price ELSE 0
    END AS sales_amount,
    CASE
        WHEN (is_cancellation OR quantity < 0) AND price > 0 AND NOT is_special_code
        THEN ABS(quantity) * price ELSE 0
    END AS return_amount
FROM flagged;

COPY (SELECT * FROM sales_extract)
TO 'data/processed/sql_extract.parquet'
(FORMAT PARQUET, COMPRESSION ZSTD);
