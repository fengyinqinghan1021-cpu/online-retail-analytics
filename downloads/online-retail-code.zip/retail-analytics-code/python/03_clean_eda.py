"""Clean the SQL extract, run exploratory analysis, and export dashboard assets."""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.colors import LinearSegmentedColormap


ROOT = Path(__file__).resolve().parents[1]
PROCESSED = ROOT / "data" / "processed"
OUTPUTS = ROOT / "outputs"
FIGURES = OUTPUTS / "figures"
FIGURES.mkdir(parents=True, exist_ok=True)

TEAL = "#0F4C5C"
CORAL = "#E36414"
SAND = "#F4EBD0"
GREEN = "#2A9D8F"
NAVY = "#1D3557"
MUTED = "#8A9A9D"
PALETTE = [TEAL, CORAL, GREEN, "#E9C46A", NAVY, "#A8DADC"]

plt.rcParams.update(
    {
        "font.sans-serif": ["Microsoft YaHei", "SimHei", "DejaVu Sans"],
        "axes.unicode_minus": False,
        "figure.dpi": 150,
        "savefig.dpi": 170,
        "axes.edgecolor": "#D8E0E3",
        "axes.labelcolor": "#33484D",
        "xtick.color": "#5A6B70",
        "ytick.color": "#5A6B70",
        "text.color": "#21383D",
        "axes.titleweight": "bold",
        "axes.titlesize": 13,
        "axes.titlepad": 12,
        "axes.grid": True,
        "grid.color": "#E8EFF1",
        "grid.linewidth": 0.8,
        "axes.axisbelow": True,
        "legend.frameon": False,
    }
)


def money(value: float) -> str:
    if abs(value) >= 1_000_000:
        return f"£{value / 1_000_000:.2f}M"
    if abs(value) >= 1_000:
        return f"£{value / 1_000:.0f}K"
    return f"£{value:,.0f}"


def pct(value: float, digits: int = 1) -> str:
    return f"{value * 100:.{digits}f}%"


def style_ax(ax: plt.Axes) -> None:
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color("#D8E0E3")
    ax.spines["bottom"].set_color("#D8E0E3")


def derive_category(description: str) -> str:
    text = (description or "").upper()
    rules = [
        ("圣诞季", ["CHRISTMAS", "XMAS", "ADVENT", "SANTA", "REINDEER", "SNOWMAN"]),
        ("厨房餐具", ["MUG", "CUP", "BOWL", "PLATE", "TEAPOT", "JUG", "CAKESTAND", "CUTLERY", "JAR", "BOTTLE", "TRAY", "EGG"]),
        ("家居装饰", ["HOLDER", "FRAME", "ORNAMENT", "DECORATION", "HEART", "T-LIGHT", "CANDLE", "LANTERN", "CLOCK", "MIRROR", "HOOK", "SIGN"]),
        ("包袋织物", ["BAG", "TOTE", "PURSE", "LUNCH", "CUSHION", "THROW", "APRON", "TOWEL", "TABLECLOTH", "NAPKIN", "BED"]),
        ("文具派对", ["CARD", "WRAP", "RIBBON", "BUNTING", "PARTY", "NOTEBOOK", "PEN", "PENCIL", "STICKER", "CHALK"]),
        ("玩具礼品", ["TOY", "GAME", "DOLL", "PLAYHOUSE", "SKIPPING", "BALL", "PUZZLE"]),
        ("饰品行头", ["NECKLACE", "BRACELET", "EARRING", "RING", "SCARF", "HAIR", "BROOCH"]),
        ("花园户外", ["GARDEN", "PLANT", "WATERING", "BIRD", "WINDMILL"]),
    ]
    for label, keywords in rules:
        if any(keyword in text for keyword in keywords):
            return label
    return "其他"


COUNTRY_CN = {
    "United Kingdom": "英国",
    "EIRE": "爱尔兰",
    "Netherlands": "荷兰",
    "Germany": "德国",
    "France": "法国",
    "Australia": "澳大利亚",
    "Switzerland": "瑞士",
    "Spain": "西班牙",
    "Sweden": "瑞典",
    "Denmark": "丹麦",
    "Belgium": "比利时",
    "Italy": "意大利",
    "Portugal": "葡萄牙",
    "Japan": "日本",
    "Norway": "挪威",
    "Finland": "芬兰",
    "Austria": "奥地利",
    "Poland": "波兰",
    "USA": "美国",
    "Canada": "加拿大",
    "Greece": "希腊",
    "Iceland": "冰岛",
    "Israel": "以色列",
    "Singapore": "新加坡",
    "Cyprus": "塞浦路斯",
    "Malta": "马耳他",
    "Hong Kong": "中国香港",
    "Korea": "韩国",
    "Lithuania": "立陶宛",
    "Czech Republic": "捷克",
    "South Africa": "南非",
    "Saudi Arabia": "沙特阿拉伯",
    "United Arab Emirates": "阿联酋",
    "Lebanon": "黎巴嫩",
    "Bahrain": "巴林",
    "Brazil": "巴西",
    "Mexico": "墨西哥",
    "India": "印度",
    "Thailand": "泰国",
    "Malaysia": "马来西亚",
    "New Zealand": "新西兰",
    "Channel Islands": "海峡群岛",
    "RSA": "南非",
}


def main() -> None:
    source = pd.read_parquet(PROCESSED / "sql_extract.parquet")
    print(f"Loaded SQL extract: {len(source):,} rows")

    # 1) Description completion using the most frequent description per SKU.
    descriptions = (
        source.dropna(subset=["description"])
        .groupby("stock_code")["description"]
        .agg(lambda values: values.mode().iloc[0])
    )
    source["description_filled"] = (
        source["description"].fillna(source["stock_code"].map(descriptions)).fillna("UNKNOWN")
    )
    source["is_guest"] = source["customer_id"].isna()
    source["price_outlier"] = False

    sale_lines = source["is_product_sale"]
    product_price = (
        source.loc[sale_lines].groupby("stock_code")["price"].median().rename("median_price")
    )
    source = source.merge(product_price, left_on="stock_code", right_index=True, how="left")
    source["price_outlier"] = (
        sale_lines
        & (source["price"] > source["median_price"] * 6)
        & (source["price"] > 50)
    )
    source["net_amount"] = source["sales_amount"] - source["return_amount"]
    source["units_sold"] = np.where(source["is_product_sale"], source["quantity"], 0)
    source["units_returned"] = np.where(
        source["is_product_return"], source["quantity"].abs(), 0
    )
    source["product_category"] = source["description_filled"].map(derive_category)

    source.to_parquet(PROCESSED / "sales_clean.parquet", index=False)

    # 2) Core KPIs.
    clean_rows = len(source)
    raw_rows = 1_067_371
    removed_duplicates = raw_rows - clean_rows
    gross_sales = float(source["sales_amount"].sum())
    returns_value = float(source["return_amount"].sum())
    net_sales = gross_sales - returns_value
    units_sold = int(source["units_sold"].sum())
    units_returned = int(source["units_returned"].sum())
    orders = int(source.loc[sale_lines, "invoice"].nunique())
    customers = int(source.loc[sale_lines, "customer_id"].dropna().nunique())
    return_rate_value = returns_value / gross_sales if gross_sales else 0
    return_rate_units = units_returned / (units_sold + units_returned)

    return_lines = source.loc[source["is_product_return"]].copy()
    invoice_returns = (
        return_lines.groupby("invoice")["return_amount"].sum().sort_values(ascending=False)
    )
    bulk_invoices = invoice_returns.head(2).index.tolist()
    bulk_return_value = float(invoice_returns.head(2).sum())
    bulk_return_share = bulk_return_value / returns_value
    largest_return = return_lines.sort_values("return_amount", ascending=False).iloc[0]
    largest_return_amount = float(largest_return["return_amount"])
    bulk_stock_codes = (
        return_lines.loc[return_lines["invoice"].isin(bulk_invoices), "stock_code"]
        .drop_duplicates()
        .tolist()
    )
    source["return_amount_excl_bulk"] = source["return_amount"]
    source.loc[
        source["invoice"].isin(bulk_invoices) & source["is_product_return"],
        "return_amount_excl_bulk",
    ] = 0
    return_rate_excl_bulk = (returns_value - bulk_return_value) / gross_sales

    order_totals = source.loc[sale_lines].groupby("invoice")["sales_amount"].sum()
    aov_mean = float(order_totals.mean())
    aov_median = float(order_totals.median())
    aov_trimmed = float(order_totals.clip(upper=order_totals.quantile(0.995)).mean())

    # 3) Monthly KPI table.
    monthly = (
        source.groupby("invoice_month", as_index=False)
        .agg(
            gross_sales=("sales_amount", "sum"),
            returns_value=("return_amount", "sum"),
            returns_value_excl_bulk=("return_amount_excl_bulk", "sum"),
            net_sales=("net_amount", "sum"),
            units_sold=("units_sold", "sum"),
            units_returned=("units_returned", "sum"),
        )
    )
    monthly_orders = (
        source.loc[sale_lines].groupby("invoice_month")["invoice"].nunique().rename("orders")
    )
    monthly_customers = (
        source.loc[sale_lines]
        .dropna(subset=["customer_id"])
        .groupby("invoice_month")["customer_id"]
        .nunique()
        .rename("customers")
    )
    monthly = monthly.merge(monthly_orders, left_on="invoice_month", right_index=True)
    monthly = monthly.merge(monthly_customers, left_on="invoice_month", right_index=True)
    monthly["aov"] = monthly["gross_sales"] / monthly["orders"]
    monthly["return_rate_value"] = monthly["returns_value"] / monthly["gross_sales"]
    monthly["return_rate_excl_bulk"] = (
        monthly["returns_value_excl_bulk"] / monthly["gross_sales"]
    )
    monthly["is_partial"] = monthly["invoice_month"].isin(
        [pd.Timestamp("2010-12-01").date(), pd.Timestamp("2011-12-01").date()]
    )
    monthly["month_label"] = monthly["invoice_month"].map(lambda value: value.strftime("%Y-%m"))
    monthly.to_csv(PROCESSED / "monthly_kpis.csv", index=False, encoding="utf-8-sig")

    full_months = monthly.loc[
        monthly["invoice_month"].between(
            pd.Timestamp("2010-01-01").date(), pd.Timestamp("2011-11-01").date()
        )
        & (~monthly["is_partial"])
    ]
    seasonal_index = (
        full_months.assign(month_num=pd.to_datetime(full_months["invoice_month"]).dt.month)
        .groupby("month_num")["net_sales"]
        .mean()
    )
    seasonal_index = seasonal_index / seasonal_index.mean()
    peak_month_num = int(seasonal_index.idxmax())
    peak_index_value = float(seasonal_index.max())

    # 4) Country and market analysis.
    country = (
        source.groupby("country", as_index=False)
        .agg(
            gross_sales=("sales_amount", "sum"),
            returns_value=("return_amount", "sum"),
            net_sales=("net_amount", "sum"),
            units_sold=("units_sold", "sum"),
        )
    )
    country_orders = (
        source.loc[sale_lines].groupby("country")["invoice"].nunique().rename("orders")
    )
    country_customers = (
        source.loc[sale_lines]
        .dropna(subset=["customer_id"])
        .groupby("country")["customer_id"]
        .nunique()
        .rename("customers")
    )
    country = country.merge(country_orders, left_on="country", right_index=True)
    country = country.merge(country_customers, left_on="country", right_index=True)
    country["aov"] = country["gross_sales"] / country["orders"]
    country["return_rate_value"] = country["returns_value"] / country["gross_sales"]

    market_window = source.loc[
        source["invoice_date"].dt.strftime("%m-%d") <= "12-09",
        ["country", "invoice_year", "net_amount"],
    ]
    market_yoy = (
        market_window.groupby(["country", "invoice_year"])["net_amount"].sum().unstack(fill_value=0)
    )
    market_yoy.columns = [f"net_{int(column)}" for column in market_yoy.columns]
    market_yoy["yoy"] = market_yoy["net_2011"] / market_yoy["net_2010"] - 1
    market_yoy = market_yoy.reset_index()
    country = country.merge(
        market_yoy[["country", "net_2010", "net_2011", "yoy"]], on="country", how="left"
    )
    country["uk_flag"] = np.where(country["country"] == "United Kingdom", "英国", "海外")
    country["country_cn"] = country["country"].map(COUNTRY_CN).fillna(country["country"])
    country = country.sort_values("net_sales", ascending=False)
    country.to_csv(PROCESSED / "country_metrics.csv", index=False, encoding="utf-8-sig")

    uk_row = country.loc[country["country"] == "United Kingdom"].iloc[0]
    uk_share = float(uk_row["net_sales"] / net_sales)
    non_uk_share = 1 - uk_share
    uk_yoy = float(uk_row["yoy"])
    non_uk_2010 = float(country.loc[country["country"] != "United Kingdom", "net_2010"].sum())
    non_uk_2011 = float(country.loc[country["country"] != "United Kingdom", "net_2011"].sum())
    non_uk_yoy = non_uk_2011 / non_uk_2010 - 1
    yoy_2010 = float(market_yoy["net_2010"].sum())
    yoy_2011 = float(market_yoy["net_2011"].sum())
    overall_yoy = yoy_2011 / yoy_2010 - 1

    # 5) Product performance and ABC classification.
    product = (
        source.groupby("stock_code", as_index=False)
        .agg(
            description=("description_filled", lambda values: values.mode().iloc[0]),
            category=("product_category", lambda values: values.mode().iloc[0]),
            gross_sales=("sales_amount", "sum"),
            returns_value=("return_amount", "sum"),
            net_sales=("net_amount", "sum"),
            units_sold=("units_sold", "sum"),
            units_returned=("units_returned", "sum"),
            avg_price=("price", "mean"),
            first_sale=("invoice_date", "min"),
            last_sale=("invoice_date", "max"),
        )
    )
    product_orders = (
        source.loc[sale_lines].groupby("stock_code")["invoice"].nunique().rename("orders")
    )
    product = product.merge(product_orders, left_on="stock_code", right_index=True)
    product["return_rate_value"] = product["returns_value"] / product["gross_sales"]
    product["return_rate_units"] = product["units_returned"] / (
        product["units_sold"] + product["units_returned"]
    )
    product = product.sort_values("net_sales", ascending=False).reset_index(drop=True)
    product["revenue_share"] = product["net_sales"] / net_sales
    product["cum_share"] = product["revenue_share"].cumsum()
    product["abc_class"] = np.select(
        [product["cum_share"] <= 0.80, product["cum_share"] <= 0.95],
        ["A", "B"],
        default="C",
    )
    product.to_csv(PROCESSED / "product_metrics.csv", index=False, encoding="utf-8-sig")
    product.head(50).to_csv(
        PROCESSED / "top_products.csv", index=False, encoding="utf-8-sig"
    )

    abc_summary = (
        product.groupby("abc_class", as_index=False)
        .agg(
            skus=("stock_code", "count"),
            net_sales=("net_sales", "sum"),
            revenue_share=("revenue_share", "sum"),
        )
        .sort_values("abc_class")
    )
    abc_summary.to_csv(PROCESSED / "abc_summary.csv", index=False, encoding="utf-8-sig")
    top10_sku_share = float(product.head(10)["revenue_share"].sum())
    top20pct_skus = int(np.ceil(len(product) * 0.2))
    top20pct_sku_share = float(product.head(top20pct_skus)["revenue_share"].sum())

    # 6) Customer RFM and Pareto.
    customer_sales = source.loc[
        sale_lines & source["customer_id"].notna()
    ].copy()
    reference_date = source["invoice_date"].max() + pd.Timedelta(days=1)
    customer = (
        customer_sales.groupby("customer_id", as_index=False)
        .agg(
            country=("country", lambda values: values.mode().iloc[0]),
            first_order=("invoice_date", "min"),
            last_order=("invoice_date", "max"),
            orders=("invoice", "nunique"),
            gross_sales=("sales_amount", "sum"),
            units=("quantity", "sum"),
        )
    )
    customer_returns = (
        source.loc[
            source["is_product_return"] & source["customer_id"].notna()
        ]
        .groupby("customer_id")["return_amount"]
        .sum()
        .rename("returns_value")
    )
    customer = customer.merge(customer_returns, left_on="customer_id", right_index=True, how="left")
    customer["returns_value"] = customer["returns_value"].fillna(0)
    customer["net_sales"] = customer["gross_sales"] - customer["returns_value"]
    customer["aov"] = customer["net_sales"] / customer["orders"]
    customer["recency_days"] = (reference_date - customer["last_order"]).dt.days

    customer["r_score"] = pd.qcut(
        customer["recency_days"].rank(method="first", ascending=True),
        5,
        labels=[5, 4, 3, 2, 1],
    ).astype(int)
    customer["f_score"] = np.select(
        [customer["orders"] <= 1, customer["orders"] <= 2, customer["orders"] <= 4, customer["orders"] <= 9],
        [1, 2, 3, 4],
        default=5,
    ).astype(int)
    customer["m_score"] = pd.qcut(
        customer["net_sales"].rank(method="first"), 5, labels=[1, 2, 3, 4, 5]
    ).astype(int)
    customer["rfm_score"] = (
        customer["r_score"].astype(str)
        + customer["f_score"].astype(str)
        + customer["m_score"].astype(str)
    )

    def segment(row: pd.Series) -> str:
        if row["r_score"] >= 4 and row["f_score"] >= 4 and row["m_score"] >= 4:
            return "核心客户"
        if row["r_score"] >= 3 and row["f_score"] >= 3:
            return "忠诚客户"
        if row["r_score"] >= 4 and row["f_score"] <= 2:
            return "新近客户"
        if row["r_score"] <= 2 and row["f_score"] >= 3:
            return "流失预警"
        if row["r_score"] <= 2 and row["f_score"] <= 2:
            return "沉睡客户"
        return "一般客户"

    customer["rfm_segment"] = customer.apply(segment, axis=1)
    customer = customer.sort_values("net_sales", ascending=False).reset_index(drop=True)
    customer["revenue_share"] = customer["net_sales"] / customer["net_sales"].sum()
    customer["cum_share"] = customer["revenue_share"].cumsum()
    customer.to_csv(PROCESSED / "customer_rfm.csv", index=False, encoding="utf-8-sig")

    pareto_points = {}
    for share in (0.01, 0.05, 0.10, 0.20):
        count = max(1, int(np.ceil(len(customer) * share)))
        pareto_points[f"top_{int(share * 100)}pct"] = float(
            customer.head(count)["revenue_share"].sum()
        )
    top20_customer_share = pareto_points["top_20pct"]

    pareto_curve = customer[["cum_share"]].copy()
    pareto_curve["customer_pct"] = np.arange(1, len(customer) + 1) / len(customer)
    pareto_curve = pareto_curve.iloc[
        np.unique(np.linspace(0, len(pareto_curve) - 1, 300).astype(int))
    ]
    pareto_curve.to_csv(PROCESSED / "customer_pareto.csv", index=False, encoding="utf-8-sig")

    def gini(values: pd.Series) -> float:
        array = np.sort(values.to_numpy(dtype=float))
        n = len(array)
        cumulative = np.cumsum(array)
        return float((n + 1 - 2 * np.sum(cumulative) / cumulative[-1]) / n)

    customer_gini = gini(customer["net_sales"])
    repeat_customer_share = float((customer["orders"] >= 2).mean())

    rfm_summary = (
        customer.groupby("rfm_segment", as_index=False)
        .agg(
            customers=("customer_id", "count"),
            net_sales=("net_sales", "sum"),
            avg_recency_days=("recency_days", "mean"),
            avg_orders=("orders", "mean"),
            avg_net_sales=("net_sales", "mean"),
        )
        .sort_values("net_sales", ascending=False)
    )
    rfm_summary["customer_share"] = rfm_summary["customers"] / rfm_summary["customers"].sum()
    rfm_summary["revenue_share"] = rfm_summary["net_sales"] / rfm_summary["net_sales"].sum()
    rfm_summary.to_csv(PROCESSED / "rfm_segments.csv", index=False, encoding="utf-8-sig")

    # 7) Cohort retention.
    cohort_base = customer_sales[["customer_id", "invoice_month"]].copy()
    cohort_base["invoice_month"] = pd.to_datetime(cohort_base["invoice_month"])
    cohort_base["cohort_month"] = cohort_base.groupby("customer_id")["invoice_month"].transform("min")
    cohort_base["period_index"] = (
        (cohort_base["invoice_month"].dt.year - cohort_base["cohort_month"].dt.year) * 12
        + cohort_base["invoice_month"].dt.month
        - cohort_base["cohort_month"].dt.month
    )
    cohort_counts = (
        cohort_base.groupby(["cohort_month", "period_index"])["customer_id"]
        .nunique()
        .reset_index(name="active_customers")
    )
    cohort_sizes = (
        cohort_base.groupby("cohort_month")["customer_id"].nunique().rename("cohort_size")
    )
    cohort_counts = cohort_counts.merge(cohort_sizes, on="cohort_month", how="left")
    cohort_counts["retention"] = (
        cohort_counts["active_customers"] / cohort_counts["cohort_size"]
    )
    cohort_counts = cohort_counts.loc[cohort_counts["cohort_size"] >= 50]
    cohort_counts.to_csv(PROCESSED / "cohort_retention.csv", index=False, encoding="utf-8-sig")

    month1_retention = cohort_counts.loc[cohort_counts["period_index"] == 1, "retention"].median()
    month6_retention = cohort_counts.loc[cohort_counts["period_index"] == 6, "retention"].median()

    # 8) Returns and operating rhythm.
    return_products = product.loc[
        (product["gross_sales"] >= 5_000) & (product["returns_value"] > 0)
    ].sort_values("returns_value", ascending=False)
    return_products.head(20).to_csv(
        PROCESSED / "return_products.csv", index=False, encoding="utf-8-sig"
    )
    return_invoices = (
        source.loc[source["is_product_return"]]
        .groupby(
            ["invoice", "invoice_date", "stock_code", "description_filled"],
            as_index=False,
        )
        .agg(
            return_amount=("return_amount", "sum"),
            units_returned=("units_returned", "sum"),
            customer_id=("customer_id", "first"),
            country=("country", "first"),
        )
        .sort_values("return_amount", ascending=False)
    )
    return_invoices.head(30).to_csv(
        PROCESSED / "return_invoices.csv", index=False, encoding="utf-8-sig"
    )

    weekday_order = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]
    weekday_map = {1: "周一", 2: "周二", 3: "周三", 4: "周四", 5: "周五", 6: "周六", 7: "周日"}
    rhythm = source.loc[sale_lines, ["invoice", "invoice_weekday", "invoice_hour"]].drop_duplicates()
    rhythm["weekday"] = rhythm["invoice_weekday"].map(weekday_map)
    weekday_hour = (
        rhythm.groupby(["weekday", "invoice_hour"])["invoice"].nunique().reset_index(name="orders")
    )
    weekday_hour.to_csv(PROCESSED / "weekday_hour_orders.csv", index=False, encoding="utf-8-sig")
    peak_hour = int(
        weekday_hour.groupby("invoice_hour")["orders"].sum().idxmax()
    )
    peak_weekday = (
        weekday_hour.groupby("weekday")["orders"].sum().sort_values(ascending=False).index[0]
    )

    data_quality = pd.DataFrame(
        [
            ("原始行数", raw_rows, "两张年度工作表合并"),
            ("跨表重复删除", removed_duplicates, "仅处理 2010-12 重叠期"),
            ("清洗后行数", clean_rows, "保留同表内重复记录"),
            ("原始缺少客户 ID 行数", 243_007, "占原始行约 22.8%"),
            ("清洗后缺少客户 ID 行数", int(source["is_guest"].sum()), "不参与客户级 RFM"),
            ("缺货品描述（清洗前）", 4_382, "按 SKU 众数描述补全"),
            ("商品取消/退货行", int((source["is_product_return"]).sum()), "含 C 开头发票与负数量"),
            ("有效商品销售行", int(source["is_product_sale"].sum()), "排除运费/手续费/手工调整"),
            ("价格异常标记行", int(source["price_outlier"].sum()), "仅标记，不删除营收"),
        ],
        columns=["指标", "数值", "说明"],
    )
    data_quality.to_csv(PROCESSED / "data_quality_summary.csv", index=False, encoding="utf-8-sig")

    kpi = {
        "period_start": str(source["invoice_date"].min().date()),
        "period_end": str(source["invoice_date"].max().date()),
        "raw_rows": raw_rows,
        "clean_rows": clean_rows,
        "removed_duplicates": removed_duplicates,
        "gross_sales": gross_sales,
        "returns_value": returns_value,
        "net_sales": net_sales,
        "return_rate_value": return_rate_value,
        "return_rate_units": return_rate_units,
        "return_rate_excl_bulk": return_rate_excl_bulk,
        "bulk_return_value": bulk_return_value,
        "bulk_return_share": bulk_return_share,
        "largest_return_value": largest_return_amount,
        "largest_return_product": str(largest_return["description_filled"]),
        "largest_return_invoice": str(largest_return["invoice"]),
        "largest_return_date": str(pd.Timestamp(largest_return["invoice_date"]).date()),
        "orders": orders,
        "customers": customers,
        "units_sold": units_sold,
        "aov_mean": aov_mean,
        "aov_median": aov_median,
        "aov_trimmed": aov_trimmed,
        "uk_share": uk_share,
        "non_uk_share": non_uk_share,
        "uk_yoy": uk_yoy,
        "non_uk_yoy": non_uk_yoy,
        "overall_yoy": overall_yoy,
        "top20_customer_share": top20_customer_share,
        "top1_customer_share": pareto_points["top_1pct"],
        "top5_customer_share": pareto_points["top_5pct"],
        "top10_customer_share": pareto_points["top_10pct"],
        "customer_gini": customer_gini,
        "repeat_customer_share": repeat_customer_share,
        "top10_sku_share": top10_sku_share,
        "top20pct_sku_share": top20pct_sku_share,
        "peak_month_num": peak_month_num,
        "peak_index": peak_index_value,
        "month1_retention": float(month1_retention),
        "month6_retention": float(month6_retention),
        "peak_hour": peak_hour,
        "peak_weekday": peak_weekday,
        "avg_full_month_sales": float(full_months["net_sales"].mean()),
    }
    (OUTPUTS / "kpi_summary.json").write_text(
        json.dumps(kpi, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    # 9) Figures.
    monthly_plot = monthly.copy()
    monthly_plot["date"] = pd.to_datetime(monthly_plot["invoice_month"])
    fig, ax = plt.subplots(figsize=(12.5, 5.6))
    colors = [MUTED if partial else TEAL for partial in monthly_plot["is_partial"]]
    ax.bar(monthly_plot["date"], monthly_plot["net_sales"], width=22, color=colors, label="净销售额")
    ax.plot(
        monthly_plot["date"],
        monthly_plot["net_sales"].rolling(3, min_periods=1).mean(),
        color=CORAL,
        linewidth=2.2,
        label="3 个月移动平均",
    )
    ax.set_title("净销售额月度趋势：11 月是全年高点")
    ax.set_ylabel("净销售额（£）")
    ax.yaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda value, _: f"{value/1000:.0f}K"))
    ax.legend(loc="upper left", ncol=2)
    ax.xaxis.set_major_locator(matplotlib.dates.MonthLocator(interval=3))
    ax.xaxis.set_major_formatter(matplotlib.dates.DateFormatter("%Y-%m"))
    ax.text(
        0.99,
        0.90,
        "浅色柱：12 月仅含 1–9 日",
        transform=ax.transAxes,
        ha="right",
        va="top",
        fontsize=9,
        color=MUTED,
    )
    style_ax(ax)
    fig.tight_layout()
    fig.savefig(FIGURES / "01_monthly_revenue.png", bbox_inches="tight", facecolor="white")
    plt.close(fig)

    top_countries = country.head(10).sort_values("net_sales")
    fig, ax = plt.subplots(figsize=(10.5, 5.4))
    bars = ax.barh(top_countries["country_cn"], top_countries["net_sales"], color=TEAL)
    bars[-1].set_color(CORAL)
    for bar, value in zip(bars, top_countries["net_sales"]):
        ax.text(value + net_sales * 0.004, bar.get_y() + bar.get_height() / 2, money(value),
                va="center", fontsize=9, color="#33484D")
    ax.set_title("市场集中度高：英国贡献绝大部分净销售额")
    ax.set_xlabel("净销售额（£）")
    ax.xaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda value, _: f"{value/1e6:.0f}M"))
    style_ax(ax)
    ax.grid(axis="y", visible=False)
    fig.tight_layout()
    fig.savefig(FIGURES / "02_market_concentration.png", bbox_inches="tight", facecolor="white")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(7.2, 5.4))
    ax.plot(pareto_curve["customer_pct"], pareto_curve["cum_share"], color=CORAL, linewidth=2.5)
    ax.plot([0, 1], [0, 1], color=MUTED, linestyle="--", linewidth=1, label="完全平均")
    ax.axvline(0.2, color=TEAL, linestyle=":", linewidth=1.5)
    ax.scatter([0.2], [top20_customer_share], color=TEAL, zorder=5, s=50)
    ax.annotate(
        f"前 20% 客户贡献 {pct(top20_customer_share)} 营收",
        xy=(0.2, top20_customer_share),
        xytext=(0.27, max(0.25, top20_customer_share - 0.28)),
        arrowprops={"arrowstyle": "->", "color": TEAL},
        fontsize=10,
        color=TEAL,
    )
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1.02)
    ax.set_xlabel("客户累计占比（按净销售额降序）")
    ax.set_ylabel("累计营收占比")
    ax.set_title("客户营收高度集中（帕累托曲线）")
    ax.xaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(1.0))
    ax.yaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(1.0))
    style_ax(ax)
    fig.tight_layout()
    fig.savefig(FIGURES / "03_customer_pareto.png", bbox_inches="tight", facecolor="white")
    plt.close(fig)

    rfm_plot = rfm_summary.sort_values("revenue_share")
    fig, axes = plt.subplots(1, 2, figsize=(11.5, 5.0))
    axes[0].barh(rfm_plot["rfm_segment"], rfm_plot["revenue_share"], color=PALETTE[: len(rfm_plot)])
    axes[0].set_title("各客群营收贡献")
    axes[0].xaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(1.0))
    axes[0].set_xlabel("营收占比")
    axes[1].barh(rfm_plot["rfm_segment"], rfm_plot["customer_share"], color=PALETTE[: len(rfm_plot)])
    axes[1].set_title("各客群客户数占比")
    axes[1].xaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(1.0))
    axes[1].set_xlabel("客户数占比")
    for ax in axes:
        style_ax(ax)
        ax.grid(axis="y", visible=False)
    fig.suptitle("RFM 客群结构：少量核心客户撑起主要营收", fontweight="bold", y=1.02)
    fig.tight_layout()
    fig.savefig(FIGURES / "04_rfm_segments.png", bbox_inches="tight", facecolor="white")
    plt.close(fig)

    fig, axes = plt.subplots(1, 2, figsize=(12.2, 5.0), gridspec_kw={"width_ratios": [1.25, 1]})
    axes[0].plot(
        monthly_plot["date"],
        monthly_plot["return_rate_value"] * 100,
        color=CORAL,
        linewidth=2,
        marker="o",
        markersize=3,
        label="全部退货",
    )
    axes[0].plot(
        monthly_plot["date"],
        monthly_plot["return_rate_excl_bulk"] * 100,
        color=TEAL,
        linewidth=1.8,
        linestyle="--",
        label="剔除两笔批量退货",
    )
    axes[0].set_title("月度退货金额率（含单笔批量退货）")
    axes[0].set_ylabel("退货金额 / 销售额（%）")
    axes[0].yaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(decimals=1))
    axes[0].xaxis.set_major_locator(matplotlib.dates.MonthLocator(interval=3))
    axes[0].xaxis.set_major_formatter(matplotlib.dates.DateFormatter("%Y-%m"))
    axes[0].tick_params(axis="x", labelrotation=30)
    axes[0].legend(loc="upper right", fontsize=8)
    last_rate = float(monthly_plot["return_rate_value"].iloc[-1] * 100)
    axes[0].annotate(
        "2011-12 单笔 £168K\n批量退货（仅 1–9 日）",
        xy=(monthly_plot["date"].iloc[-1], last_rate),
        xytext=(-105, -58),
        textcoords="offset points",
        fontsize=8,
        color=CORAL,
        arrowprops={"arrowstyle": "->", "color": CORAL, "lw": 1},
    )
    style_ax(axes[0])
    top_returns = (
        return_products.loc[~return_products["stock_code"].isin(bulk_stock_codes)]
        .head(8)
        .sort_values("returns_value")
    )
    axes[1].barh(
        top_returns["description"].str.slice(0, 24),
        top_returns["returns_value"],
        color=CORAL,
    )
    axes[1].set_title("剔除两笔批量退货后的商品退货额")
    axes[1].set_xlabel("退货金额（£）")
    style_ax(axes[1])
    axes[1].grid(axis="y", visible=False)
    fig.suptitle("退货管理：整体可控，但少数商品值得单独复盘", fontweight="bold", y=1.02)
    fig.tight_layout()
    fig.savefig(FIGURES / "05_returns.png", bbox_inches="tight", facecolor="white")
    plt.close(fig)

    cohort_pivot = cohort_counts.pivot(
        index="cohort_month", columns="period_index", values="retention"
    ).iloc[:18, :12]
    fig, ax = plt.subplots(figsize=(11.5, 6.8))
    cmap = LinearSegmentedColormap.from_list("retention", ["#F7FBFC", TEAL])
    heatmap_data = cohort_pivot.fillna(0)
    image = ax.imshow(heatmap_data, aspect="auto", cmap=cmap, vmin=0, vmax=0.6)
    ax.set_xticks(range(heatmap_data.shape[1]))
    ax.set_xticklabels([f"M+{index}" for index in heatmap_data.columns], fontsize=8)
    ax.set_yticks(range(heatmap_data.shape[0]))
    ax.set_yticklabels([pd.Timestamp(value).strftime("%Y-%m") for value in heatmap_data.index], fontsize=8)
    for row in range(heatmap_data.shape[0]):
        for column in range(heatmap_data.shape[1]):
            value = heatmap_data.iloc[row, column]
            if value > 0:
                ax.text(column, row, f"{value*100:.0f}", ha="center", va="center",
                        fontsize=7, color="white" if value > 0.32 else "#33484D")
    ax.set_title("月度客户留存热力图（数字为留存率 %）")
    ax.set_xlabel("首购后月数")
    ax.set_ylabel("首购月份（cohort）")
    fig.colorbar(image, ax=ax, fraction=0.025, pad=0.02, format=matplotlib.ticker.PercentFormatter(1.0))
    fig.tight_layout()
    fig.savefig(FIGURES / "06_cohort_retention.png", bbox_inches="tight", facecolor="white")
    plt.close(fig)

    rhythm_pivot = (
        weekday_hour.pivot(index="weekday", columns="invoice_hour", values="orders")
        .reindex(weekday_order)
        .fillna(0)
    )
    fig, ax = plt.subplots(figsize=(11.0, 4.2))
    image = ax.imshow(rhythm_pivot, aspect="auto", cmap=cmap)
    ax.set_xticks(range(len(rhythm_pivot.columns)))
    ax.set_xticklabels([f"{int(hour):02d}" for hour in rhythm_pivot.columns], fontsize=8)
    ax.set_yticks(range(len(rhythm_pivot.index)))
    ax.set_yticklabels(rhythm_pivot.index)
    ax.set_xlabel("下单小时")
    ax.set_ylabel("星期")
    ax.set_title("订单时段分布：工作日上午与中午最繁忙")
    fig.colorbar(image, ax=ax, fraction=0.025, pad=0.02, label="订单数")
    fig.tight_layout()
    fig.savefig(FIGURES / "07_weekday_hour.png", bbox_inches="tight", facecolor="white")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(9.2, 5.0))
    abc_plot = abc_summary.sort_values("abc_class")
    ax.bar(abc_plot["abc_class"], abc_plot["revenue_share"], color=[TEAL, GREEN, "#E9C46A"])
    for index, row in abc_plot.iterrows():
        ax.text(
            list(abc_plot["abc_class"]).index(row["abc_class"]),
            row["revenue_share"] + 0.015,
            f"{row['skus']:.0f} 个 SKU\n{pct(row['revenue_share'])}",
            ha="center",
            fontsize=9,
        )
    ax.set_ylim(0, 1)
    ax.set_ylabel("营收占比")
    ax.set_title("SKU ABC 分层：A 类商品贡献约八成营收")
    ax.yaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(1.0))
    style_ax(ax)
    fig.tight_layout()
    fig.savefig(FIGURES / "08_product_abc.png", bbox_inches="tight", facecolor="white")
    plt.close(fig)

    # 10) Power BI star schema.
    fact = source.loc[
        source["is_product_sale"] | source["is_product_return"],
        [
            "line_id",
            "invoice",
            "stock_code",
            "customer_id",
            "country",
            "invoice_date_key",
            "invoice_date",
            "invoice_month",
            "quantity",
            "price",
            "sales_amount",
            "return_amount",
            "net_amount",
            "units_sold",
            "units_returned",
            "is_product_return",
            "is_guest",
        ],
    ].copy()
    fact.rename(
        columns={
            "invoice_date_key": "date_key",
            "is_product_return": "is_return",
            "is_guest": "is_guest_customer",
        },
        inplace=True,
    )
    fact.to_parquet(PROCESSED / "fact_sales.parquet", index=False)

    date_range = pd.date_range(source["invoice_date"].min().normalize(), source["invoice_date"].max().normalize())
    dim_date = pd.DataFrame(
        {
            "date_key": date_range.strftime("%Y%m%d").astype(int),
            "date": date_range,
            "year": date_range.year,
            "quarter": date_range.quarter,
            "month": date_range.month,
            "year_month": date_range.strftime("%Y-%m"),
            "month_name": date_range.strftime("%Y-%m"),
            "weekday": date_range.dayofweek + 1,
            "weekday_name": date_range.strftime("%A"),
            "is_weekend": (date_range.dayofweek + 1 >= 6).astype(int),
        }
    )
    dim_date.to_csv(PROCESSED / "dim_date.csv", index=False, encoding="utf-8-sig")

    dim_product = product[
        ["stock_code", "description", "category", "abc_class", "first_sale", "last_sale"]
    ].rename(columns={"category": "product_category"})
    dim_product.to_csv(PROCESSED / "dim_product.csv", index=False, encoding="utf-8-sig")

    dim_customer = customer[
        [
            "customer_id",
            "country",
            "first_order",
            "last_order",
            "orders",
            "net_sales",
            "recency_days",
            "r_score",
            "f_score",
            "m_score",
            "rfm_segment",
        ]
    ].copy()
    dim_customer.to_csv(PROCESSED / "dim_customer.csv", index=False, encoding="utf-8-sig")

    dim_country = country[
        ["country", "country_cn", "uk_flag", "net_sales", "orders", "customers", "yoy"]
    ].copy()
    dim_country.to_csv(PROCESSED / "dim_country.csv", index=False, encoding="utf-8-sig")

    print(json.dumps(kpi, ensure_ascii=False, indent=2))
    print(f"Figures: {len(list(FIGURES.glob('*.png')))}")


if __name__ == "__main__":
    main()
