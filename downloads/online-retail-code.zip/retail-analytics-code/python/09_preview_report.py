"""Render report PDF pages to PNG for visual QA."""

from pathlib import Path

import pymupdf


ROOT = Path(__file__).resolve().parents[1]
PDF = ROOT / "reports" / "项目报告.pdf"
OUT = ROOT / "outputs" / "preview"
OUT.mkdir(parents=True, exist_ok=True)


def main() -> None:
    document = pymupdf.open(PDF)
    for index, page in enumerate(document):
        pixmap = page.get_pixmap(dpi=140)
        output = OUT / f"report-{index + 1}.png"
        pixmap.save(output)
        print(output.name)
    print(f"pages={document.page_count}")
    document.close()


if __name__ == "__main__":
    main()
