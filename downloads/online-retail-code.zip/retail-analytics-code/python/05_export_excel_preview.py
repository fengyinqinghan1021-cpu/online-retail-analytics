"""Export key Excel sheets to PDF/PNG for visual QA (requires Microsoft Excel)."""

from __future__ import annotations

from pathlib import Path

import fitz
import win32com.client


ROOT = Path(__file__).resolve().parents[1]
WORKBOOK = ROOT / "outputs" / "Online_Retail_II_商业分析看板.xlsx"
PREVIEW_DIR = ROOT / "outputs" / "preview"
PREVIEW_DIR.mkdir(parents=True, exist_ok=True)


def main() -> None:
    excel = win32com.client.DispatchEx("Excel.Application")
    excel.Visible = False
    excel.DisplayAlerts = False
    excel.AskToUpdateLinks = False
    workbook = excel.Workbooks.Open(str(WORKBOOK), ReadOnly=True, UpdateLinks=0)
    try:
        for sheet_name, file_stem in [
            ("项目首页", "excel_cover"),
            ("管理看板", "excel_dashboard"),
            ("业务结论", "excel_conclusions"),
        ]:
            sheet = workbook.Worksheets(sheet_name)
            sheet.Select()
            pdf_path = PREVIEW_DIR / f"{file_stem}.pdf"
            sheet.ExportAsFixedFormat(0, str(pdf_path), Quality=0)
            document = fitz.open(pdf_path)
            page = document[0]
            pixmap = page.get_pixmap(dpi=150)
            pixmap.save(PREVIEW_DIR / f"{file_stem}.png")
            document.close()
            print(f"Exported {sheet_name} -> {pdf_path.name}")
    finally:
        workbook.Close(SaveChanges=False)
        excel.Quit()


if __name__ == "__main__":
    main()
