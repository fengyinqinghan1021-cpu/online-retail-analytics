"""Build the project landing page, printable report, and README."""

from __future__ import annotations

import html
import json
import subprocess
import tempfile
from pathlib import Path

import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
OUTPUTS = ROOT / "outputs"
FIGURES = OUTPUTS / "figures"
REPORTS = ROOT / "reports"
REPORTS.mkdir(parents=True, exist_ok=True)


def money_m(value: float) -> str:
    return f"£{value / 1_000_000:.2f}M"


def pct(value: float, digits: int = 1) -> str:
    return f"{value * 100:.{digits}f}%"


def load_context() -> dict:
    kpi = json.loads((OUTPUTS / "kpi_summary.json").read_text(encoding="utf-8"))
    country = pd.read_csv(ROOT / "data" / "processed" / "country_metrics.csv")
    rfm = pd.read_csv(ROOT / "data" / "processed" / "rfm_segments.csv")
    quality = pd.read_csv(ROOT / "data" / "processed" / "data_quality_summary.csv")
    country_map = country.set_index("country")
    rfm_map = rfm.set_index("rfm_segment")
    return {
        "kpi": kpi,
        "quality": quality,
        "france_yoy": float(country_map.loc["France", "yoy"]),
        "germany_yoy": float(country_map.loc["Germany", "yoy"]),
        "netherlands_yoy": float(country_map.loc["Netherlands", "yoy"]),
        "core_revenue": float(rfm_map.loc["核心客户", "revenue_share"]),
        "core_customers": float(rfm_map.loc["核心客户", "customer_share"]),
        "at_risk_revenue": float(rfm_map.loc["流失预警", "revenue_share"]),
        "at_risk_customers": float(rfm_map.loc["流失预警", "customer_share"]),
    }


CSS = """
:root {
  --navy:#1D3557; --teal:#0F4C5C; --coral:#E36414; --green:#2A9D8F;
  --sand:#F4EBD0; --ink:#21383D; --muted:#5A6B70; --line:#DCE5E8;
  --bg:#F5F8F9; --white:#FFFFFF; --gold:#C58B2A;
}
* { box-sizing:border-box; }
html { scroll-behavior:smooth; }
body {
  margin:0; background:var(--bg); color:var(--ink);
  font-family:"Microsoft YaHei","Segoe UI",Arial,sans-serif;
  line-height:1.7; -webkit-font-smoothing:antialiased;
}
a { color:inherit; }
.wrap { width:min(1180px, calc(100% - 40px)); margin:0 auto; }
.hero {
  background:
    radial-gradient(900px 420px at 85% -10%, rgba(227,100,20,.28), transparent 60%),
    linear-gradient(135deg,#13263F 0%, #1D3557 55%, #0F4C5C 100%);
  color:#fff; padding:28px 0 58px; position:relative; overflow:hidden;
}
.hero::after {
  content:""; position:absolute; inset:0; opacity:.12; pointer-events:none;
  background-image:linear-gradient(rgba(255,255,255,.35) 1px,transparent 1px),
                   linear-gradient(90deg,rgba(255,255,255,.35) 1px,transparent 1px);
  background-size:42px 42px;
}
.nav { display:flex; align-items:center; justify-content:space-between; gap:20px; position:relative; z-index:2; }
.brand { display:flex; align-items:center; gap:12px; font-weight:700; letter-spacing:.08em; font-size:13px; }
.brand-mark { width:34px; height:34px; border-radius:10px; background:var(--coral); display:grid; place-items:center; font-size:16px; }
.nav-links { display:flex; gap:22px; font-size:13px; color:#DCE7EA; }
.nav-links a { text-decoration:none; }
.nav-links a:hover { color:#fff; }
.hero-inner { position:relative; z-index:2; padding-top:64px; max-width:900px; }
.eyebrow { color:#F2C9AE; font-size:12px; letter-spacing:.18em; font-weight:700; text-transform:uppercase; }
h1 { font-size:clamp(36px,5.4vw,68px); line-height:1.12; margin:14px 0 18px; letter-spacing:-.03em; }
h1 span { color:#F4EBD0; font-weight:500; font-size:.56em; display:block; margin-top:12px; letter-spacing:-.01em; }
.hero p { color:#DCE7EA; font-size:16px; max-width:760px; margin:0 0 26px; }
.actions { display:flex; flex-wrap:wrap; gap:12px; margin-bottom:20px; }
.btn { display:inline-flex; align-items:center; justify-content:center; padding:11px 18px; border-radius:9px;
  text-decoration:none; font-size:13px; font-weight:700; background:rgba(255,255,255,.12);
  border:1px solid rgba(255,255,255,.25); color:#fff; transition:.2s; }
.btn:hover { transform:translateY(-2px); background:rgba(255,255,255,.2); }
.btn.primary { background:var(--coral); border-color:var(--coral); }
.btn.primary:hover { background:#d95a10; }
.badges { display:flex; flex-wrap:wrap; gap:8px; color:#BFD2D8; font-size:12px; }
.badges span { border:1px solid rgba(255,255,255,.2); padding:4px 9px; border-radius:999px; }
main { padding:0 0 60px; }
.kpis { display:grid; grid-template-columns:repeat(5,1fr); gap:14px; margin-top:-30px; position:relative; z-index:3; }
.kpi { background:var(--white); border:1px solid var(--line); border-radius:14px; padding:18px 18px 16px; box-shadow:0 10px 26px rgba(18,38,63,.08); }
.kpi .label { color:var(--muted); font-size:11px; letter-spacing:.06em; }
.kpi .value { font-size:27px; font-weight:800; color:var(--teal); line-height:1.25; margin-top:6px; letter-spacing:-.02em; }
.kpi .note { color:#4E6368; font-size:11px; margin-top:4px; }
.kpi.accent { background:var(--navy); border-color:var(--navy); }
.kpi.accent .label,.kpi.accent .note { color:#BFD2D8; }
.kpi.accent .value { color:#fff; }
section { margin-top:54px; }
.section-head { display:flex; align-items:flex-end; justify-content:space-between; gap:20px; margin-bottom:18px; }
.section-head h2 { font-size:26px; margin:0; color:var(--navy); letter-spacing:-.02em; }
.section-head p { margin:0; color:var(--muted); font-size:13px; max-width:600px; }
.grid-3 { display:grid; grid-template-columns:repeat(3,1fr); gap:14px; }
.grid-2 { display:grid; grid-template-columns:repeat(2,1fr); gap:18px; }
.card { background:var(--white); border:1px solid var(--line); border-radius:14px; padding:20px; transition:.2s; }
.card:hover { transform:translateY(-3px); box-shadow:0 14px 30px rgba(18,38,63,.09); }
.card h3 { margin:0 0 6px; font-size:16px; color:var(--navy); }
.card p { margin:0; color:var(--muted); font-size:13px; }
.card .meta { margin-top:14px; color:var(--coral); font-size:12px; font-weight:700; }
.card a { text-decoration:none; display:block; }
.preview { border-radius:16px; overflow:hidden; border:1px solid var(--line); background:#fff; box-shadow:0 16px 38px rgba(18,38,63,.1); }
.preview img { display:block; width:100%; height:auto; }
.preview-caption { padding:12px 16px; color:var(--muted); font-size:12px; border-top:1px solid var(--line); }
.pipeline { display:grid; grid-template-columns:repeat(4,1fr); gap:12px; }
.step { background:#fff; border:1px solid var(--line); border-radius:14px; padding:18px; position:relative; }
.step .num { width:28px; height:28px; border-radius:8px; background:var(--sand); color:var(--navy); display:grid; place-items:center; font-weight:800; font-size:12px; }
.step h3 { font-size:15px; margin:12px 0 6px; color:var(--navy); }
.step p { margin:0; font-size:12px; color:var(--muted); }
.fig-grid { display:grid; grid-template-columns:repeat(2,1fr); gap:18px; }
figure { margin:0; background:#fff; border:1px solid var(--line); border-radius:14px; overflow:hidden; }
figure img { display:block; width:100%; height:auto; }
figcaption { padding:10px 14px; font-size:12px; color:var(--muted); border-top:1px solid var(--line); }
.finding { display:grid; grid-template-columns:56px 1fr; gap:16px; background:#fff; border:1px solid var(--line); border-radius:14px; padding:18px 20px; }
.finding .idx { width:48px; height:48px; border-radius:14px; background:var(--navy); color:#fff; display:grid; place-items:center; font-size:20px; font-weight:800; }
.finding h3 { margin:0 0 5px; font-size:16px; color:var(--navy); }
.finding p { margin:0; font-size:13px; color:var(--muted); }
.finding p strong { color:var(--ink); }
.quality { width:100%; border-collapse:collapse; background:#fff; border:1px solid var(--line); border-radius:14px; overflow:hidden; }
.quality th,.quality td { padding:11px 14px; text-align:left; border-bottom:1px solid #EDF2F3; font-size:12.5px; }
.quality th { background:var(--navy); color:#fff; font-weight:600; }
.quality tr:last-child td { border-bottom:none; }
.quality td:first-child { font-weight:700; color:var(--navy); }
.code { background:#0F1E2E; color:#DCE7EA; border-radius:14px; padding:18px 20px; overflow:auto; font-size:12px; line-height:1.8; }
.code code { font-family:Consolas,Monaco,monospace; }
.note { background:var(--sand); border:1px solid #E9D8A6; border-radius:12px; padding:14px 16px; color:#6B5420; font-size:12.5px; }
footer { border-top:1px solid var(--line); color:var(--muted); font-size:12px; padding:26px 0 40px; }
footer a { color:var(--teal); }
@media (max-width:980px) {
  .kpis { grid-template-columns:repeat(2,1fr); margin-top:18px; }
  .grid-3,.pipeline,.fig-grid { grid-template-columns:1fr 1fr; }
}
@media (max-width:640px) {
  .nav-links { display:none; }
  .kpis,.grid-3,.grid-2,.pipeline,.fig-grid { grid-template-columns:1fr; }
  .section-head { display:block; }
  .section-head p { margin-top:6px; }
  h1 { font-size:38px; }
}
@media print {
  body { background:#fff; }
  .hero { print-color-adjust:exact; -webkit-print-color-adjust:exact; }
  .actions,.nav-links { display:none; }
}
"""


def build_index(ctx: dict) -> Path:
    kpi = ctx["kpi"]
    quality = ctx["quality"]
    findings = [
        (
            "Q4 峰值明确，增长高度依赖 11 月",
            f"22 个完整月份中，11 月净销售额平均为月均的 <strong>{kpi['peak_index']:.2f} 倍</strong>；2011-11 净销售额 £1.43M。",
            "备货、客服与仓配前置到 9–10 月；A 类 SKU 设置 11 月安全库存。",
        ),
        (
            "客户集中度高，核心客户是营收基本盘",
            f"前 1% 客户贡献 <strong>{pct(kpi['top1_customer_share'], 1)}</strong>，前 20% 贡献 <strong>{pct(kpi['top20_customer_share'], 1)}</strong>；核心客户占 {pct(ctx['core_customers'], 1)} 人数、贡献 {pct(ctx['core_revenue'], 1)} 营收。",
            "建立核心客户专属服务与补货提醒；对流失预警客群做召回。",
        ),
        (
            "海外市场是主要增量，英国增长接近饱和",
            f"非英国市场同比 <strong>+{pct(kpi['non_uk_yoy'], 1)}</strong>，英国仅 +{pct(kpi['uk_yoy'], 1)}；法国 +{pct(ctx['france_yoy'], 1)}、德国 +{pct(ctx['germany_yoy'], 1)}、荷兰 +{pct(ctx['netherlands_yoy'], 1)}。",
            "优先深耕法国、德国、荷兰；澳大利亚先验证复购，再加大投入。",
        ),
        (
            "退货整体可控，但被少数批量退货放大",
            f"全部退货金额率 <strong>{pct(kpi['return_rate_value'], 2)}</strong>；两笔批量退货占退货额 {pct(kpi['bulk_return_share'], 1)}；剔除后常规退货率 <strong>{pct(kpi['return_rate_excl_bulk'], 2)}</strong>。",
            "批发取消与消费者退货分开考核；高退货金额商品做质检与包装复盘。",
        ),
        (
            "商品组合呈典型长尾，A 类 SKU 决定大盘",
            f"<strong>1,038 个 A 类 SKU 贡献 80.0% 营收</strong>；前 20% SKU 贡献 {pct(kpi['top20pct_sku_share'], 1)}；2,430 个 C 类 SKU 仅贡献 5.0%。",
            "A 类保供保曝光；B 类做组合与价格测试；C 类按动销与退货率逐步淘汰。",
        ),
    ]
    finding_html = "".join(
        f"""
        <article class="finding">
          <div class="idx">{index + 1:02d}</div>
          <div>
            <h3>{html.escape(title)}</h3>
            <p>{evidence}</p>
            <p style="margin-top:5px;color:var(--teal)"><strong>建议：</strong>{html.escape(action)}</p>
          </div>
        </article>
        """
        for index, (title, evidence, action) in enumerate(findings)
    )
    quality_rows = "".join(
        f"<tr><td>{html.escape(str(row['指标']))}</td><td>{int(row['数值']):,}</td><td>{html.escape(str(row['说明']))}</td></tr>"
        for _, row in quality.iterrows()
        if str(row["数值"]).replace(".", "", 1).isdigit()
    )
    deliverables = [
        ("Excel 管理看板", "outputs/Online_Retail_II_商业分析看板.xlsx", "8 个工作表 · 原生可交互图表 · 5 条结论与数据字典", "打开 .xlsx"),
        ("Power BI 工程", "powerbi/OnlineRetailII/OnlineRetailII.pbip", "TMDL 语义模型 · 2 页 PBIR 报表 · 14 个 DAX 指标", "打开 .pbip"),
        ("项目报告 PDF", "reports/项目报告.pdf", "方法论、数据质量、关键图表与业务建议", "阅读 PDF"),
        ("SQL 查询", "sql/02_build_extract.sql", "画像、跨表去重、清洗抽取与业务聚合", "查看 SQL"),
        ("Python 流程", "python/03_clean_eda.py", "清洗、RFM、cohort、ABC、图表与数据导出", "查看 Python"),
        ("数据源", "https://archive.ics.uci.edu/dataset/502/online+retail+ii", "UCI Online Retail II 公开数据集（2009–2011）", "访问 UCI"),
    ]
    deliverable_html = "".join(
        f"""
        <a class="card" href="{html.escape(url)}">
          <h3>{html.escape(title)}</h3>
          <p>{html.escape(desc)}</p>
          <div class="meta">{html.escape(meta)} →</div>
        </a>
        """
        for title, url, desc, meta in deliverables
    )

    index_html = f"""<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Online Retail II | 从 SQL 到 Power BI 的商业分析项目</title>
<style>{CSS}</style>
</head>
<body>
<header class="hero">
  <div class="wrap">
    <nav class="nav">
      <div class="brand"><span class="brand-mark">R</span> RETAIL ANALYTICS</div>
      <div class="nav-links">
        <a href="#deliverables">交付物</a>
        <a href="#pipeline">分析流程</a>
        <a href="#charts">关键图表</a>
        <a href="#findings">业务结论</a>
        <a href="#reproduce">复现</a>
      </div>
    </nav>
    <div class="hero-inner">
      <div class="eyebrow">PUBLIC DATA · END-TO-END ANALYTICS</div>
      <h1>Online Retail II<span>从 SQL 查询到 Power BI 看板的完整商业分析</span></h1>
      <p>用 106.7 万行英国在线零售交易，回答四个问题：钱从哪里来、客户是谁、增长在哪里、退货是否失控。全流程可复现，含 SQL、Python、Excel 与 Power BI 交付物。</p>
      <div class="actions">
        <a class="btn primary" href="outputs/Online_Retail_II_商业分析看板.xlsx">打开 Excel 看板</a>
        <a class="btn" href="powerbi/OnlineRetailII/OnlineRetailII.pbip">打开 Power BI 工程</a>
        <a class="btn" href="reports/项目报告.pdf">阅读项目报告</a>
      </div>
      <div class="badges"><span>SQL / DuckDB</span><span>Python / pandas</span><span>Excel</span><span>Power BI / PBIP</span><span>RFM · Cohort · ABC</span></div>
    </div>
  </div>
</header>

<main class="wrap">
  <section class="kpis" aria-label="核心指标">
    <div class="kpi accent"><div class="label">净销售额</div><div class="value">{money_m(kpi['net_sales'])}</div><div class="note">商品销售扣除退货</div></div>
    <div class="kpi"><div class="label">有效订单</div><div class="value">{kpi['orders']:,}</div><div class="note">按发票去重</div></div>
    <div class="kpi"><div class="label">客户数</div><div class="value">{kpi['customers']:,}</div><div class="note">有 Customer ID</div></div>
    <div class="kpi"><div class="label">常规退货率</div><div class="value">{pct(kpi['return_rate_excl_bulk'], 2)}</div><div class="note">全部退货率 {pct(kpi['return_rate_value'], 2)}</div></div>
    <div class="kpi"><div class="label">英国营收占比</div><div class="value">{pct(kpi['uk_share'], 1)}</div><div class="note">海外市场同比 +{pct(kpi['non_uk_yoy'], 1)}</div></div>
  </section>

  <section id="deliverables">
    <div class="section-head">
      <h2>项目交付物</h2>
      <p>同一套指标口径贯穿 SQL、Python、Excel 与 Power BI；点击卡片即可打开对应文件。</p>
    </div>
    <div class="grid-3">{deliverable_html}</div>
  </section>

  <section>
    <div class="section-head">
      <h2>看板预览</h2>
      <p>Excel 管理看板：一页看清营收、客户、市场与退货；下方为报表结构说明。</p>
    </div>
    <div class="preview">
      <img src="outputs/preview/excel_dashboard.png" alt="Excel 管理看板预览">
      <div class="preview-caption">Excel 管理看板 · 原生图表与 KPI 卡片 · 可打印为 A4 横向</div>
    </div>
  </section>

  <section id="pipeline">
    <div class="section-head">
      <h2>分析流程</h2>
      <p>从原始 Excel 到可交互看板，每一步都有版本化脚本和可核对的输出。</p>
    </div>
    <div class="pipeline">
      <div class="step"><div class="num">01</div><h3>SQL 查询与画像</h3><p>DuckDB 读取原始表，完成行数、缺失、重复、取消单与特殊 SKU 画像；识别 2010-12 跨表重叠。</p></div>
      <div class="step"><div class="num">02</div><h3>Python 清洗与 EDA</h3><p>只删除跨表重复；补全商品描述；拆分销售/退货；构建 RFM、cohort、ABC 与市场同比。</p></div>
      <div class="step"><div class="num">03</div><h3>Excel + Power BI</h3><p>Excel 做管理看板与明细；Power BI 建事实/维度模型，提供可切片的交互式报表。</p></div>
      <div class="step"><div class="num">04</div><h3>5 条业务结论</h3><p>把数据证据转成可执行动作：旺季备货、核心客户、海外增长、退货治理、SKU 优化。</p></div>
    </div>
  </section>

  <section id="charts">
    <div class="section-head">
      <h2>关键图表</h2>
      <p>所有图表均由 Python 从清洗后数据直接生成，保证口径一致、可复现。</p>
    </div>
    <div class="fig-grid">
      <figure><img src="outputs/figures/01_monthly_revenue.png" alt="月度净销售额"><figcaption>月度净销售额：11 月为全年峰值</figcaption></figure>
      <figure><img src="outputs/figures/02_market_concentration.png" alt="市场集中度"><figcaption>市场集中度：英国占 85.5%</figcaption></figure>
      <figure><img src="outputs/figures/03_customer_pareto.png" alt="客户帕累托"><figcaption>客户帕累托：前 20% 客户贡献 76.7%</figcaption></figure>
      <figure><img src="outputs/figures/05_returns.png" alt="退货分析"><figcaption>退货分析：批量退货与常规退货分层</figcaption></figure>
      <figure><img src="outputs/figures/04_rfm_segments.png" alt="RFM 客群"><figcaption>RFM 客群：核心客户贡献 68.7% 营收</figcaption></figure>
      <figure><img src="outputs/figures/06_cohort_retention.png" alt="客户留存热力图"><figcaption>月度 cohort 留存：首购后 1 个月留存约 20%</figcaption></figure>
    </div>
  </section>

  <section id="findings">
    <div class="section-head">
      <h2>5 条业务结论</h2>
      <p>每条结论都附数据证据与下一步动作，避免“只看图、不落地”。</p>
    </div>
    <div style="display:grid;gap:12px">{finding_html}</div>
  </section>

  <section>
    <div class="section-head">
      <h2>数据质量与清洗口径</h2>
      <p>关键判断：2010-12 两张年度表重叠 9 天，产生约 2.28 万条跨表重复；只删除跨表重复，保留同表内可能的真实重复录入。</p>
    </div>
    <table class="quality">
      <thead><tr><th>指标</th><th>数值</th><th>说明</th></tr></thead>
      <tbody>{quality_rows}</tbody>
    </table>
  </section>

  <section id="reproduce">
    <div class="section-head">
      <h2>如何复现</h2>
      <p>在项目根目录依次执行以下脚本；完整流程约 2–3 分钟（首次读取 Excel 较慢）。</p>
    </div>
    <div class="code"><code>cd retail-analytics
python python/01_ingest.py
python python/02_sql_pipeline.py --full
python python/03_clean_eda.py
python python/04_build_excel.py
python python/06_build_powerbi.py
python python/07_validate_powerbi.py</code></div>
    <div class="note" style="margin-top:14px">Power BI：用 Power BI Desktop 打开 <code>powerbi/OnlineRetailII/OnlineRetailII.pbip</code>；如数据目录不同，在“转换数据 → 管理参数”中修改 <code>DataPath</code> 后刷新。PBIP 的 JSON 已通过微软官方 PBIR Schema 校验。</div>
  </section>
</main>

<footer>
  <div class="wrap">
    数据源：<a href="https://archive.ics.uci.edu/dataset/502/online+retail+ii">UCI Machine Learning Repository — Online Retail II</a>
    · 分析范围：2009-12-01 至 2011-12-09 · 货币：英镑（£）
    · 本项目仅用于分析与作品展示。
  </div>
</footer>
</body>
</html>
"""
    path = ROOT / "index.html"
    path.write_text(index_html, encoding="utf-8")
    return path


REPORT_CSS = """
@page { size:A4; margin:14mm 14mm 16mm; }
* { box-sizing:border-box; }
body { margin:0; font-family:"Microsoft YaHei","Segoe UI",Arial,sans-serif; color:#21383D; line-height:1.65; background:#fff; }
.page { page-break-after:always; }
.page:last-child { page-break-after:auto; }
.cover { background:linear-gradient(135deg,#13263F,#1D3557 58%,#0F4C5C); color:#fff; margin:-14mm -14mm 0; padding:20mm 16mm 16mm; min-height:265mm; }
.eyebrow { font-size:10px; letter-spacing:.18em; color:#F2C9AE; font-weight:700; }
h1 { font-size:38px; line-height:1.15; margin:10px 0 8px; letter-spacing:-.03em; }
.sub { font-size:15px; color:#DCE7EA; max-width:160mm; }
.kpis { display:grid; grid-template-columns:repeat(3,1fr); gap:8px; margin:16mm 0 10mm; }
.kpi { background:rgba(255,255,255,.1); border:1px solid rgba(255,255,255,.18); border-radius:8px; padding:10px 12px; }
.kpi b { display:block; font-size:20px; color:#fff; }
.kpi span { font-size:9px; color:#BFD2D8; }
.cover .note { font-size:10px; color:#BFD2D8; margin-top:8mm; }
h2 { font-size:21px; color:#1D3557; margin:0 0 4mm; letter-spacing:-.02em; }
h3 { font-size:13px; color:#1D3557; margin:0 0 2mm; }
p { font-size:10.5px; margin:0 0 3mm; }
.lead { font-size:11px; color:#5A6B70; margin-bottom:6mm; }
.grid2 { display:grid; grid-template-columns:1fr 1fr; gap:6mm; }
.grid3 { display:grid; grid-template-columns:repeat(3,1fr); gap:5mm; }
.box { border:1px solid #DCE5E8; border-radius:8px; padding:5mm; background:#fff; }
.box.soft { background:#F5F8F9; }
.box h3 { margin-bottom:2mm; }
.box p { margin:0; color:#5A6B70; font-size:9.8px; }
.tag { display:inline-block; padding:2px 7px; border-radius:999px; background:#F4EBD0; color:#6B5420; font-size:8.5px; font-weight:700; margin-bottom:2mm; }
table { width:100%; border-collapse:collapse; margin:3mm 0 5mm; }
th,td { border-bottom:1px solid #E8EFF1; padding:2.2mm 2.5mm; text-align:left; font-size:9.5px; }
th { background:#1D3557; color:#fff; font-weight:600; }
td:first-child { font-weight:700; color:#1D3557; }
img { width:100%; display:block; border:1px solid #DCE5E8; border-radius:6px; }
.fig { margin:0 0 5mm; }
.fig figcaption { font-size:8.5px; color:#5A6B70; margin-top:1.5mm; }
.finding { border-left:3px solid #E36414; padding:2mm 0 2mm 4mm; margin-bottom:4mm; }
.finding h3 { font-size:12px; margin:0 0 1mm; }
.finding p { font-size:9.6px; margin:0; color:#5A6B70; }
.finding b { color:#21383D; }
.footer { margin-top:8mm; padding-top:3mm; border-top:1px solid #DCE5E8; color:#8A9A9D; font-size:8px; }
.code { background:#0F1E2E; color:#DCE7EA; border-radius:6px; padding:4mm 5mm; font:8.5px/1.8 Consolas,monospace; white-space:pre-wrap; }
.link { color:#0F4C5C; text-decoration:none; font-weight:700; }
"""


def build_report(ctx: dict) -> Path:
    kpi = ctx["kpi"]
    quality = ctx["quality"]
    quality_rows = "".join(
        f"<tr><td>{html.escape(str(row['指标']))}</td><td>{int(row['数值']):,}</td><td>{html.escape(str(row['说明']))}</td></tr>"
        for _, row in quality.iterrows()
        if str(row["数值"]).replace(".", "", 1).isdigit()
    )
    report = f"""<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><title>Online Retail II 分析报告</title><style>{REPORT_CSS}</style></head>
<body>
<div class="page cover">
  <div class="eyebrow">PUBLIC DATA · END-TO-END ANALYTICS</div>
  <h1>Online Retail II<br>商业分析报告</h1>
  <div class="sub">英国在线零售商 2009–2011 交易数据 · SQL 查询 → Python 清洗与 EDA → Excel / Power BI 看板 → 5 条业务结论</div>
  <div class="kpis">
    <div class="kpi"><b>{money_m(kpi['net_sales'])}</b><span>净销售额</span></div>
    <div class="kpi"><b>{kpi['orders']:,}</b><span>有效订单</span></div>
    <div class="kpi"><b>{kpi['customers']:,}</b><span>客户数</span></div>
    <div class="kpi"><b>{pct(kpi['return_rate_excl_bulk'], 2)}</b><span>常规退货率</span></div>
    <div class="kpi"><b>{pct(kpi['uk_share'], 1)}</b><span>英国营收占比</span></div>
    <div class="kpi"><b>{pct(kpi['non_uk_yoy'], 1)}</b><span>海外市场同比</span></div>
  </div>
  <div class="note">数据源：UCI Machine Learning Repository — Online Retail II（公开数据集）<br>
  分析范围：2009-12-01 至 2011-12-09 · 货币：英镑（£） · 粒度：订单行<br>
  项目入口：index.html · Excel：outputs/Online_Retail_II_商业分析看板.xlsx · Power BI：powerbi/OnlineRetailII/OnlineRetailII.pbip</div>
</div>

<div class="page">
  <h2>01 数据与方法</h2>
  <p class="lead">目标不是“把数据画出来”，而是建立一套可核对、可复现、能支持经营决策的分析链路。</p>
  <div class="grid2">
    <div class="box"><span class="tag">SQL</span><h3>画像与抽取</h3><p>DuckDB 对 1,067,371 行做字段画像、重复识别和跨表重叠检查；用 ROW_NUMBER 只删除 2010-12 重叠期的跨表重复，保留同表内可能的真实重复录入。</p></div>
    <div class="box"><span class="tag">Python</span><h3>清洗与探索</h3><p>统一 SKU 大小写、补全缺失描述、拆分商品销售/退货、标记特殊 SKU 与价格异常；构建月度、国家、SKU、RFM、cohort、ABC 等分析表。</p></div>
  </div>
  <table>
    <thead><tr><th>数据质量指标</th><th>数值</th><th>说明</th></tr></thead>
    <tbody>{quality_rows}</tbody>
  </table>
  <div class="grid3">
    <div class="box soft"><h3>销售口径</h3><p>非取消发票、数量 &gt; 0、单价 &gt; 0、非运费/手续费/调整等特殊 SKU；净销售额 = 销售 − 退货。</p></div>
    <div class="box soft"><h3>客户口径</h3><p>RFM 只覆盖有 Customer ID 的 5,852 位客户；游客订单仍计入整体营收，但不进入客群分析。</p></div>
    <div class="box soft"><h3>退货口径</h3><p>同时展示“全部退货率”和“剔除两笔批量退货后的常规退货率”，避免单笔批发取消扭曲商品质量判断。</p></div>
  </div>
  <div class="footer">Online Retail II · 分析报告 · 02</div>
</div>

<div class="page">
  <h2>02 经营表现</h2>
  <p class="lead">营收在 11 月集中爆发，市场高度集中于英国，海外是更快的增量来源。</p>
  <div class="grid2">
    <figure class="fig"><img src="../outputs/figures/01_monthly_revenue.png"><figcaption>月度净销售额：完整月份中 11 月平均为月均的 1.83 倍</figcaption></figure>
    <figure class="fig"><img src="../outputs/figures/02_market_concentration.png"><figcaption>市场集中度：英国 £16.22M，占 85.5%</figcaption></figure>
  </div>
  <div class="finding"><h3>结论 1 · Q4 峰值明确，增长高度依赖 11 月</h3><p>22 个完整月份中，11 月净销售额平均为月均的 <b>1.83 倍</b>；2011-11 净销售额 £1.43M。建议将旺季备货、临时客服与仓配能力前置到 9–10 月，对 A 类 SKU 设置 11 月安全库存。</p></div>
  <div class="finding"><h3>结论 2 · 海外市场是主要增量</h3><p>非英国市场同比 <b>+{pct(kpi['non_uk_yoy'], 1)}</b>，英国仅 +{pct(kpi['uk_yoy'], 1)}；法国 +{pct(ctx['france_yoy'], 1)}、德国 +{pct(ctx['germany_yoy'], 1)}、荷兰 +{pct(ctx['netherlands_yoy'], 1)}。建议优先深耕法国、德国、荷兰，先验证澳大利亚的可持续复购。</p></div>
  <div class="footer">Online Retail II · 分析报告 · 03</div>
</div>

<div class="page">
  <h2>03 客户、商品与退货</h2>
  <p class="lead">客户与商品都呈明显的“少数贡献多数”；退货需要区分批量取消与常规商品退货。</p>
  <div class="grid2">
    <figure class="fig"><img src="../outputs/figures/03_customer_pareto.png"><figcaption>前 20% 客户贡献 76.7% 净销售额</figcaption></figure>
    <figure class="fig"><img src="../outputs/figures/05_returns.png"><figcaption>全部退货率 3.65%；剔除两笔批量退货后 2.41%</figcaption></figure>
  </div>
  <div class="grid2">
    <figure class="fig"><img src="../outputs/figures/04_rfm_segments.png"><figcaption>核心客户 21.5% 人数，贡献 68.7% 营收</figcaption></figure>
    <figure class="fig"><img src="../outputs/figures/08_product_abc.png"><figcaption>A 类 1,038 个 SKU 贡献 80% 营收</figcaption></figure>
  </div>
  <div class="finding"><h3>结论 3 · 客户集中度高，核心客户是营收基本盘</h3><p>前 1% 客户贡献 <b>31.1%</b>，前 20% 客户贡献 <b>76.7%</b>；核心客户以 {pct(ctx['core_customers'], 1)} 的人数贡献 {pct(ctx['core_revenue'], 1)} 营收。建议建立核心客户专属服务与补货提醒，对流失预警客群（{pct(ctx['at_risk_customers'], 1)} 人数、{pct(ctx['at_risk_revenue'], 1)} 营收）做召回。</p></div>
  <div class="finding"><h3>结论 4 · 退货整体可控，但被少数批量退货放大</h3><p>全部退货金额率 <b>{pct(kpi['return_rate_value'], 2)}</b>；两笔批量退货合计 £245.7K，占退货额 34.1%；剔除后常规退货率 <b>{pct(kpi['return_rate_excl_bulk'], 2)}</b>。建议将批发取消/整单退货与消费者退货分开考核。</p></div>
  <div class="finding"><h3>结论 5 · 商品组合呈典型长尾</h3><p>1,038 个 A 类 SKU 贡献 80.0% 营收；前 20% SKU 贡献 77.9%；2,430 个 C 类 SKU 仅贡献 5.0%。建议 A 类保供保曝光、B 类做组合与价格测试、C 类按动销与退货率逐步淘汰。</p></div>
  <div class="footer">Online Retail II · 分析报告 · 04</div>
</div>

<div class="page">
  <h2>04 交付物与复现</h2>
  <p class="lead">同一套指标口径贯穿 SQL、Python、Excel 与 Power BI；所有图表与数字均可由脚本重建。</p>
  <div class="grid3">
    <div class="box"><h3>Excel 看板</h3><p><b>outputs/Online_Retail_II_商业分析看板.xlsx</b><br>8 个工作表：首页、管理看板、客户分析、商品与退货、市场分析、业务结论、数据附表、数据字典。</p></div>
    <div class="box"><h3>Power BI 工程</h3><p><b>powerbi/OnlineRetailII/OnlineRetailII.pbip</b><br>TMDL 语义模型、2 页 PBIR 报表、14 个 DAX 指标；用 Power BI Desktop 打开并刷新。</p></div>
    <div class="box"><h3>项目入口</h3><p><b>index.html</b><br>汇总所有交付物链接、关键图表、结论与复现步骤，适合作为作品集首页。</p></div>
  </div>
  <h3 style="margin-top:8mm">复现命令</h3>
  <div class="code">cd retail-analytics
python python/01_ingest.py
python python/02_sql_pipeline.py --full
python python/03_clean_eda.py
python python/04_build_excel.py
python python/06_build_powerbi.py
python python/07_validate_powerbi.py</div>
  <h3 style="margin-top:7mm">Power BI 打开说明</h3>
  <p>使用 Power BI Desktop 打开 <b>OnlineRetailII.pbip</b>。若数据目录不同，在“转换数据 → 管理参数”中把 <b>DataPath</b> 改为本机 <b>data/processed</b> 的绝对路径，然后刷新。PBIR 报表 JSON 已通过微软官方 Schema 校验，28 个字段/度量引用均已在 TMDL 模型中核对。</p>
  <div class="box soft" style="margin-top:5mm"><h3>数据源与说明</h3><p>UCI Machine Learning Repository — Online Retail II。原始数据包含两张年度表，2010-12 有 9 天重叠；本报告只删除跨表重复，保留同表内重复记录。项目仅用于分析与作品展示。</p></div>
  <div class="footer">Online Retail II · 分析报告 · 05</div>
</div>
</body></html>"""
    path = REPORTS / "项目报告.html"
    path.write_text(report, encoding="utf-8")
    return path


def build_pdf(html_path: Path) -> Path | None:
    edge = Path(r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe")
    if not edge.exists():
        edge = Path(r"C:\Program Files\Microsoft\Edge\Application\msedge.exe")
    if not edge.exists():
        print("Edge not found; skipped PDF generation.")
        return None
    pdf_path = REPORTS / "项目报告.pdf"
    with tempfile.TemporaryDirectory() as profile:
        command = [
            str(edge),
            "--headless",
            "--disable-gpu",
            "--no-pdf-header-footer",
            f"--user-data-dir={profile}",
            f"--print-to-pdf={pdf_path}",
            html_path.as_uri(),
        ]
        subprocess.run(command, check=True, capture_output=True, timeout=90)
    print(f"Wrote {pdf_path}")
    return pdf_path


README_TEMPLATE = """# Online Retail II 商业分析项目

用公开数据集完成一条可复现的端到端分析链路：**SQL 查询 → Python 清洗与 EDA → Excel / Power BI 看板 → 5 条业务结论**。

[打开项目主页](index.html) · [打开 Excel 看板](outputs/Online_Retail_II_商业分析看板.xlsx) · [打开 Power BI 工程](powerbi/OnlineRetailII/OnlineRetailII.pbip) · [阅读项目报告](reports/项目报告.pdf)

## 核心指标

| 指标 | 数值 |
|---|---:|
| 净销售额 | £18.98M |
| 有效订单 | 39,516 |
| 客户数（有 ID） | 5,852 |
| 全部退货率 | 3.65% |
| 常规退货率（剔除两笔批量退货） | 2.41% |
| 英国营收占比 | 85.5% |
| 非英国市场同比 | +15.3% |

## 5 条业务结论

1. **Q4 峰值明确，增长高度依赖 11 月。** 22 个完整月份中，11 月净销售额平均为月均的 1.83 倍；建议旺季备货与客服排班前置到 9–10 月。
2. **客户集中度高。** 前 1% 客户贡献 31.1% 营收，前 20% 客户贡献 76.7%；核心客户以 21.5% 的人数贡献 68.7% 营收。
3. **海外是主要增量。** 非英国市场同比 +15.3%，英国仅 +0.4%；法国 +54.9%、德国 +10.5%、荷兰 +10.9%。
4. **退货需分层管理。** 全部退货率 3.65%，两笔批量退货占退货额 34.1%；剔除后常规退货率 2.41%。
5. **商品组合呈长尾。** 1,038 个 A 类 SKU 贡献 80% 营收；前 20% SKU 贡献 77.9%，2,430 个 C 类 SKU 仅贡献 5%。

## 数据与方法

- 数据源：[UCI Online Retail II](https://archive.ics.uci.edu/dataset/502/online+retail+ii)，2009-12-01 至 2011-12-09，1,067,371 行。
- SQL：DuckDB 做字段画像、重复识别与跨表重叠检查；只删除 2010-12 重叠期的跨表重复（22,844 行）。
- Python：统一 SKU 大小写、补全缺失描述、拆分销售/退货、构建月度/国家/SKU/RFM/cohort/ABC 分析表。
- Excel：原生图表的管理看板 + 客户/商品/市场/结论/数据字典。
- Power BI：PBIP 工程，TMDL 语义模型（事实表 + 4 个维度 + 6 张预聚合表）与 2 页 PBIR 报表。

## 项目结构

```text
retail-analytics/
├─ index.html                     # 项目入口页
├─ README.md
├─ data/
│  ├─ raw/                        # 原始 zip / xlsx
│  ├─ processed/                  # 清洗后 parquet、维度表、汇总表
│  └─ query_results/              # SQL 画像结果
├─ sql/                           # 01 画像、02 清洗抽取
├─ python/                        # 01–08 全流程脚本
├─ outputs/
│  ├─ Online_Retail_II_商业分析看板.xlsx
│  ├─ figures/                    # Python 生成图表
│  └─ preview/                    # Excel 渲染预览
├─ reports/                       # 项目报告 HTML/PDF
└─ powerbi/OnlineRetailII/        # PBIP 工程
```

## 复现

```powershell
cd retail-analytics
.\run_all.ps1
```

或分步执行：

```powershell
python python/01_ingest.py
python python/02_sql_pipeline.py --full
python python/03_clean_eda.py
python python/04_build_excel.py
python python/06_build_powerbi.py
python python/07_validate_powerbi.py
```

依赖：`pandas`、`numpy`、`pyarrow`、`duckdb`、`openpyxl`、`xlsxwriter`、`matplotlib`、`seaborn`、`pymupdf`、`jsonschema`、`requests`、`pywin32`（Excel 预览导出可选）。

## Power BI 打开说明

1. 用 Power BI Desktop 打开 `powerbi/OnlineRetailII/OnlineRetailII.pbip`。
2. 若数据目录不同，在“转换数据 → 管理参数”中把 `DataPath` 改为本机 `data/processed` 的绝对路径。
3. 刷新数据。语义模型通过 Parquet 读取事实表/维度表，避免 CSV 编码与类型问题。
4. PBIR 报表 JSON 已通过微软官方 Schema 校验；28 个字段/度量引用均已在 TMDL 中核对。

## 口径说明

- 净销售额 = 商品销售 − 退货；排除运费、手续费、手工调整、礼品券等特殊 SKU。
- 客户级 RFM 仅覆盖有 Customer ID 的客户；游客订单仍计入整体营收。
- 退货分析同时展示全部退货率与剔除两笔批量退货后的常规退货率，避免单笔批发取消扭曲判断。
- 同比口径为 2010-01-01 至 2010-12-09 vs 2011-01-01 至 2011-12-09，避免 12 月仅 9 天造成偏差。

## 数据源

[UCI Machine Learning Repository — Online Retail II](https://archive.ics.uci.edu/dataset/502/online+retail+ii)
"""


def build_readme() -> Path:
    path = ROOT / "README.md"
    path.write_text(README_TEMPLATE, encoding="utf-8")
    return path


def main() -> None:
    ctx = load_context()
    index = build_index(ctx)
    report_html = build_report(ctx)
    build_pdf(report_html)
    readme = build_readme()
    print(f"Wrote {index}")
    print(f"Wrote {report_html}")
    print(f"Wrote {readme}")


if __name__ == "__main__":
    main()
