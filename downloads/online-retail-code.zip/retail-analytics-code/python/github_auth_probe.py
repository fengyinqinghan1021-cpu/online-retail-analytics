"""Check for a stored GitHub credential without printing the secret."""

from __future__ import annotations

import json
import subprocess
import urllib.error
import urllib.request


def main() -> None:
    result = subprocess.run(
        ["git", "credential", "fill"],
        input="protocol=https\nhost=github.com\n\n",
        text=True,
        capture_output=True,
        check=False,
    )
    values = {}
    for line in result.stdout.splitlines():
        if "=" in line:
            key, value = line.split("=", 1)
            values[key] = value
    token = values.get("password")
    if not token:
        print("No stored GitHub credential found.")
        return
    request = urllib.request.Request(
        "https://api.github.com/user",
        headers={
            "Authorization": f"Bearer {token}",
            "Accept": "application/vnd.github+json",
            "User-Agent": "Codex-GitHub-Publisher",
        },
    )
    try:
        with urllib.request.urlopen(request, timeout=20) as response:
            payload = json.loads(response.read().decode("utf-8"))
            scopes = response.headers.get("X-OAuth-Scopes", "")
    except urllib.error.HTTPError as error:
        print(f"Stored credential rejected by GitHub API: HTTP {error.code}")
        return
    print(f"Authenticated as: {payload.get('login')}")
    print(f"Name: {payload.get('name') or '(not set)'}")
    print(f"OAuth scopes: {scopes or '(none reported)'}")


if __name__ == "__main__":
    main()
