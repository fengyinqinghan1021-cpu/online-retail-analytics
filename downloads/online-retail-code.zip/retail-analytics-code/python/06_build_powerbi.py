"""Generate a Power BI Project (PBIP) with a TMDL model and PBIR report pages."""

from __future__ import annotations

import json
import shutil
import uuid
from pathlib import Path

import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
PROCESSED = ROOT / "data" / "processed"
PBI_ROOT = ROOT / "powerbi" / "OnlineRetailII"
REPORT_DIR = PBI_ROOT / "OnlineRetailII.Report"
MODEL_DIR = PBI_ROOT / "OnlineRetailII.SemanticModel"

REPORT_SCHEMA = "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/report/3.0.0/schema.json"
PAGE_SCHEMA = "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/page/2.0.0/schema.json"
VISUAL_SCHEMA = "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/visualContainer/2.3.0/schema.json"

DATA_PATH = str(PROCESSED).replace("\\", "/")
NS = uuid.UUID("0b7b9e2e-4b7a-4f5f-9f6c-8a6f2e1d4c3b")


def stable_id(name: str) -> str:
    return str(uuid.uuid5(NS, name))


def write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def prepare_parquet_outputs() -> None:
    """Mirror CSV analysis outputs as Parquet so Power Query only has one source type."""
    mappings = {
        "dim_date.csv": ("dim_date.parquet", ["date"]),
        "dim_product.csv": ("dim_product.parquet", ["first_sale", "last_sale"]),
        "dim_customer.csv": ("dim_customer.parquet", ["first_order", "last_order"]),
        "dim_country.csv": ("dim_country.parquet", []),
        "rfm_segments.csv": ("rfm_summary.parquet", []),
        "customer_pareto.csv": ("customer_pareto.parquet", []),
        "product_metrics.csv": ("product_metrics.parquet", ["first_sale", "last_sale"]),
        "return_invoices.csv": ("return_invoices.parquet", ["invoice_date"]),
    }
    for source_name, (output_name, date_columns) in mappings.items():
        frame = pd.read_csv(PROCESSED / source_name)
        for column in date_columns:
            frame[column] = pd.to_datetime(frame[column], errors="coerce")
        frame.to_parquet(PROCESSED / output_name, index=False)

    cohort = pd.read_csv(PROCESSED / "cohort_retention.csv")
    cohort["cohort_month"] = pd.to_datetime(cohort["cohort_month"]).dt.strftime("%Y-%m")
    cohort["period_label"] = "M+" + cohort["period_index"].astype(int).astype(str)
    cohort.to_parquet(PROCESSED / "cohort.parquet", index=False)

    top_products = pd.read_csv(PROCESSED / "top_products.csv")
    top_products.to_parquet(PROCESSED / "product_top.parquet", index=False)

    country = pd.read_csv(PROCESSED / "country_metrics.csv")
    country.loc[country["country"] != "United Kingdom"].head(10).to_parquet(
        PROCESSED / "country_top.parquet", index=False
    )


TABLES: dict[str, dict] = {
    "FactSales": {
        "file": "fact_sales.parquet",
        "columns": [
            ("line_id", "int64", "none"),
            ("invoice", "string", "none"),
            ("stock_code", "string", "none"),
            ("customer_id", "string", "none"),
            ("country", "string", "none"),
            ("date_key", "int64", "none"),
            ("invoice_date", "dateTime", "none"),
            ("invoice_month", "dateTime", "none"),
            ("quantity", "int64", "sum"),
            ("price", "double", "none"),
            ("sales_amount", "double", "sum"),
            ("return_amount", "double", "sum"),
            ("net_amount", "double", "sum"),
            ("units_sold", "int64", "sum"),
            ("units_returned", "int64", "sum"),
            ("is_return", "boolean", "none"),
            ("is_guest_customer", "boolean", "none"),
        ],
        "measures": {
            "净销售额": ("SUM(FactSales[net_amount])", "£#,0"),
            "销售总额": ("SUM(FactSales[sales_amount])", "£#,0"),
            "退货金额": ("SUM(FactSales[return_amount])", "£#,0"),
            "订单数": ("DISTINCTCOUNT(FactSales[invoice])", "#,0"),
            "客户数": ("DISTINCTCOUNT(FactSales[customer_id])", "#,0"),
            "销量": ("SUM(FactSales[units_sold])", "#,0"),
            "退货件数": ("SUM(FactSales[units_returned])", "#,0"),
            "客单价": ("DIVIDE([销售总额], [订单数])", "£#,0"),
            "退货率": ("DIVIDE([退货金额], [销售总额])", "0.00%"),
            "批量退货金额": (
                'CALCULATE([退货金额], FactSales[invoice] IN {"C581484", "C541433"})',
                "£#,0",
            ),
            "常规退货率": ("DIVIDE([退货金额] - [批量退货金额], [销售总额])", "0.00%"),
            "同比增长率": (
                "VAR CurrentSales = [净销售额]\n"
                "VAR PriorSales = CALCULATE([净销售额], DATEADD(DimDate[date], -1, YEAR))\n"
                "RETURN DIVIDE(CurrentSales - PriorSales, PriorSales)",
                "0.0%;-0.0%;0.0%",
            ),
            "单客户净销售额": ("DIVIDE([净销售额], [客户数])", "£#,0"),
            "英国营收占比": (
                'DIVIDE(CALCULATE([净销售额], DimCountry[country] = "United Kingdom"), [净销售额])',
                "0.00%",
            ),
        },
    },
    "DimDate": {
        "file": "dim_date.parquet",
        "columns": [
            ("date_key", "int64", "none"),
            ("date", "dateTime", "none"),
            ("year", "int64", "none"),
            ("quarter", "int64", "none"),
            ("month", "int64", "none"),
            ("year_month", "string", "none"),
            ("month_name", "string", "none"),
            ("weekday", "int64", "none"),
            ("weekday_name", "string", "none"),
            ("is_weekend", "int64", "none"),
        ],
        "measures": {},
    },
    "DimProduct": {
        "file": "dim_product.parquet",
        "columns": [
            ("stock_code", "string", "none"),
            ("description", "string", "none"),
            ("product_category", "string", "none"),
            ("abc_class", "string", "none"),
            ("first_sale", "dateTime", "none"),
            ("last_sale", "dateTime", "none"),
        ],
        "measures": {},
    },
    "DimCustomer": {
        "file": "dim_customer.parquet",
        "columns": [
            ("customer_id", "string", "none"),
            ("country", "string", "none"),
            ("first_order", "dateTime", "none"),
            ("last_order", "dateTime", "none"),
            ("orders", "int64", "none"),
            ("net_sales", "double", "none"),
            ("recency_days", "int64", "none"),
            ("r_score", "int64", "none"),
            ("f_score", "int64", "none"),
            ("m_score", "int64", "none"),
            ("rfm_segment", "string", "none"),
        ],
        "measures": {},
    },
    "DimCountry": {
        "file": "dim_country.parquet",
        "columns": [
            ("country", "string", "none"),
            ("country_cn", "string", "none"),
            ("uk_flag", "string", "none"),
            ("net_sales", "double", "none"),
            ("orders", "int64", "none"),
            ("customers", "int64", "none"),
            ("yoy", "double", "none"),
        ],
        "measures": {},
    },
    "CountryTop": {
        "file": "country_top.parquet",
        "columns": [
            ("country", "string", "none"),
            ("country_cn", "string", "none"),
            ("net_sales", "double", "none"),
            ("orders", "int64", "none"),
            ("customers", "int64", "none"),
            ("yoy", "double", "none"),
        ],
        "measures": {
            "净销售额": ("SUM(CountryTop[net_sales])", "£#,0"),
        },
    },
    "RfmSummary": {
        "file": "rfm_summary.parquet",
        "columns": [
            ("rfm_segment", "string", "none"),
            ("customers", "int64", "none"),
            ("net_sales", "double", "none"),
            ("avg_recency_days", "double", "none"),
            ("avg_orders", "double", "none"),
            ("avg_net_sales", "double", "none"),
            ("customer_share", "double", "none"),
            ("revenue_share", "double", "none"),
        ],
        "measures": {},
    },
    "CustomerPareto": {
        "file": "customer_pareto.parquet",
        "columns": [
            ("customer_pct", "double", "none"),
            ("cum_share", "double", "none"),
        ],
        "measures": {},
    },
    "Cohort": {
        "file": "cohort.parquet",
        "columns": [
            ("cohort_month", "string", "none"),
            ("period_index", "int64", "none"),
            ("period_label", "string", "none"),
            ("active_customers", "int64", "none"),
            ("cohort_size", "int64", "none"),
            ("retention", "double", "none"),
        ],
        "measures": {},
    },
    "ProductTop": {
        "file": "product_top.parquet",
        "columns": [
            ("description", "string", "none"),
            ("stock_code", "string", "none"),
            ("product_category", "string", "none"),
            ("gross_sales", "double", "none"),
            ("returns_value", "double", "none"),
            ("net_sales", "double", "none"),
            ("units_sold", "int64", "none"),
            ("units_returned", "int64", "none"),
            ("avg_price", "double", "none"),
            ("orders", "int64", "none"),
            ("return_rate_value", "double", "none"),
            ("return_rate_units", "double", "none"),
            ("revenue_share", "double", "none"),
            ("cum_share", "double", "none"),
            ("abc_class", "string", "none"),
        ],
        "measures": {},
    },
    "ReturnInvoices": {
        "file": "return_invoices.parquet",
        "columns": [
            ("invoice", "string", "none"),
            ("invoice_date", "dateTime", "none"),
            ("stock_code", "string", "none"),
            ("description_filled", "string", "none"),
            ("return_amount", "double", "none"),
            ("units_returned", "int64", "none"),
            ("customer_id", "string", "none"),
            ("country", "string", "none"),
        ],
        "measures": {},
    },
}


M_TYPE = {
    "int64": "Int64.Type",
    "double": "type number",
    "string": "type text",
    "boolean": "type logical",
    "dateTime": "type datetime",
}


def generate_tmdl() -> None:
    if PBI_ROOT.exists():
        shutil.rmtree(PBI_ROOT)
    (MODEL_DIR / "definition" / "tables").mkdir(parents=True, exist_ok=True)
    (MODEL_DIR / "definition" / "cultures").mkdir(parents=True, exist_ok=True)
    (REPORT_DIR / "definition" / "pages").mkdir(parents=True, exist_ok=True)
    (REPORT_DIR / "StaticResources" / "RegisteredResources").mkdir(parents=True, exist_ok=True)

    model_lines = [
        "model Model",
        "\tculture: en-GB",
        "\tdefaultPowerBIDataSourceVersion: powerBI_V3",
        "\tsourceQueryCulture: en-GB",
        "\tdataAccessOptions",
        "\t\tlegacyRedirects",
        "\t\treturnErrorValuesAsNull",
        "",
        'annotation PBI_QueryOrder = ["DataPath", ' + ", ".join(f'"{name}"' for name in TABLES) + "]",
        "",
    ]
    for name in TABLES:
        model_lines.append(f"ref table {name}")
    model_lines.extend(["", "ref cultureInfo en-GB", ""])
    (MODEL_DIR / "definition" / "model.tmdl").write_text("\n".join(model_lines), encoding="utf-8")

    (MODEL_DIR / "definition" / "database.tmdl").write_text("database\n\tcompatibilityLevel: 1567\n", encoding="utf-8")
    (MODEL_DIR / "definition" / "cultures" / "en-GB.tmdl").write_text("cultureInfo en-GB\n", encoding="utf-8")
    (MODEL_DIR / "definition" / "relationships.tmdl").write_text(
        "\n".join(
            [
                f"relationship {stable_id('rel_fact_date')}",
                "\tfromColumn: FactSales.date_key",
                "\ttoColumn: DimDate.date_key",
                "",
                f"relationship {stable_id('rel_fact_product')}",
                "\tfromColumn: FactSales.stock_code",
                "\ttoColumn: DimProduct.stock_code",
                "",
                f"relationship {stable_id('rel_fact_customer')}",
                "\tfromColumn: FactSales.customer_id",
                "\ttoColumn: DimCustomer.customer_id",
                "",
                f"relationship {stable_id('rel_fact_country')}",
                "\tfromColumn: FactSales.country",
                "\ttoColumn: DimCountry.country",
                "",
            ]
        ),
        encoding="utf-8",
    )
    (MODEL_DIR / "definition" / "expressions.tmdl").write_text(
        "\n".join(
            [
                f'expression DataPath = "{DATA_PATH}" meta [IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true]',
                f"\tlineageTag: {stable_id('expr_datapath')}",
                "\tannotation PBI_ResultType = Text",
                "",
            ]
        ),
        encoding="utf-8",
    )

    for table_name, spec in TABLES.items():
        lines = [f"table {table_name}", f"\tlineageTag: {stable_id('table_' + table_name)}", ""]
        for column_name, data_type, summarize in spec["columns"]:
            lines.extend(
                [
                    f"\tcolumn {column_name}",
                    f"\t\tdataType: {data_type}",
                    f"\t\tsummarizeBy: {summarize}",
                    f"\t\tsourceColumn: {column_name}",
                    f"\t\tlineageTag: {stable_id(f'{table_name}.{column_name}')}",
                    "",
                ]
            )
        for measure_name, (expression, format_string) in spec["measures"].items():
            expression_lines = expression.splitlines()
            if len(expression_lines) == 1:
                lines.append(f"\tmeasure '{measure_name}' = {expression}")
            else:
                lines.append(f"\tmeasure '{measure_name}' =")
                for expression_line in expression_lines:
                    lines.append(f"\t\t\t{expression_line}")
            lines.extend(
                [
                    f"\t\tformatString: {format_string}",
                    "\t\tdisplayFolder: 01 核心指标",
                    f"\t\tlineageTag: {stable_id(f'{table_name}.{measure_name}')}",
                    "",
                ]
            )
        column_type_pairs = ", ".join(
            f'{{"{column_name}", {M_TYPE[data_type]}}}' for column_name, data_type, _ in spec["columns"]
        )
        lines.extend(
            [
                f"\tpartition {table_name} = m",
                "\t\tmode: import",
                "\t\tsource =",
                "\t\t\t\tlet",
                f'\t\t\t\t    Source = Parquet.Document(File.Contents(DataPath & "/{spec["file"]}")),',
                f'\t\t\t\t    #"Changed Type" = Table.TransformColumnTypes(Source,{{{column_type_pairs}}})',
                "\t\t\t\tin",
                '\t\t\t\t    #"Changed Type"',
                "",
            ]
        )
        (MODEL_DIR / "definition" / "tables" / f"{table_name}.tmdl").write_text(
            "\n".join(lines), encoding="utf-8"
        )

    write_json(
        MODEL_DIR / "definition.pbism",
        {
            "$schema": "https://developer.microsoft.com/json-schemas/fabric/item/semanticModel/definitionProperties/1.0.0/schema.json",
            "version": "4.2",
            "settings": {},
        },
    )
    write_json(
        MODEL_DIR / ".platform",
        {
            "$schema": "https://developer.microsoft.com/json-schemas/fabric/gitIntegration/platformProperties/2.0.0/schema.json",
            "metadata": {"type": "SemanticModel", "displayName": "OnlineRetailII"},
            "config": {"version": "2.0", "logicalId": stable_id("model_logical")},
        },
    )


def literal(value: str) -> dict:
    return {"expr": {"Literal": {"Value": value}}}


def solid_color(color: str) -> dict:
    return {"solid": {"color": {"expr": {"Literal": {"Value": f"'{color}'"}}}}}


def column_field(entity: str, prop: str) -> dict:
    return {"Column": {"Expression": {"SourceRef": {"Entity": entity}}, "Property": prop}}


def measure_field(entity: str, prop: str) -> dict:
    return {"Measure": {"Expression": {"SourceRef": {"Entity": entity}}, "Property": prop}}


def aggregation_field(entity: str, prop: str, function: int) -> dict:
    return {
        "Aggregation": {
            "Expression": {"Column": {"Expression": {"SourceRef": {"Entity": entity}}, "Property": prop}},
            "Function": function,
        }
    }


def projection(field: dict, query_ref: str, display_name: str | None = None) -> dict:
    payload = {"field": field, "queryRef": query_ref, "nativeQueryRef": display_name or query_ref.split(".")[-1]}
    if display_name:
        payload["displayName"] = display_name
    return payload


def visual_title(text: str, size: str = "11D") -> dict:
    return {
        "title": [
            {
                "properties": {
                    "show": literal("true"),
                    "text": literal(f"'{text}'"),
                    "fontSize": literal(size),
                    "bold": literal("true"),
                }
            }
        ]
    }


def container(
    name: str,
    visual_type: str,
    x: float,
    y: float,
    width: float,
    height: float,
    *,
    query_state: dict | None = None,
    sort: dict | None = None,
    title: str | None = None,
    objects: dict | None = None,
    filters: dict | None = None,
    z: int = 0,
) -> dict:
    visual: dict = {"visualType": visual_type}
    if query_state:
        visual["query"] = {"queryState": query_state}
        if sort:
            visual["query"]["sortDefinition"] = sort
    if objects:
        visual["objects"] = objects
    if title:
        visual["visualContainerObjects"] = visual_title(title)
    visual["drillFilterOtherVisuals"] = True
    payload = {
        "$schema": VISUAL_SCHEMA,
        "name": name,
        "position": {"x": x, "y": y, "z": z, "height": height, "width": width, "tabOrder": z},
        "visual": visual,
    }
    if filters:
        payload["filterConfig"] = filters
    return payload


def textbox(name: str, x: float, y: float, width: float, height: float, paragraphs: list[dict]) -> dict:
    return container(
        name,
        "textbox",
        x,
        y,
        width,
        height,
        objects={"general": [{"properties": {"paragraphs": paragraphs}}]},
    )


def paragraph(text: str, size: int = 12, bold: bool = False, align: str = "left") -> dict:
    style = {"fontFamily": "Microsoft YaHei", "fontSize": f"{size}pt"}
    if bold:
        style["fontWeight"] = "bold"
    return {"textRuns": [{"value": text, "textStyle": style}], "horizontalTextAlignment": align}


def card(name: str, measure_name: str, x: float, y: float, width: float, height: float) -> dict:
    return container(
        name,
        "card",
        x,
        y,
        width,
        height,
        query_state={
            "Values": {
                "projections": [
                    projection(measure_field("FactSales", measure_name), f"FactSales.{measure_name}", measure_name)
                ]
            }
        },
    )


def overseas_filter() -> dict:
    return {
        "filters": [
            {
                "name": "excludeUnitedKingdom",
                "field": column_field("DimCountry", "country"),
                "type": "Categorical",
                "filter": {
                    "Version": 2,
                    "From": [{"Name": "c", "Entity": "DimCountry", "Type": 0}],
                    "Where": [
                        {
                            "Condition": {
                                "Not": {
                                    "Expression": {
                                        "In": {
                                            "Expressions": [
                                                {"Column": {"Expression": {"SourceRef": {"Source": "c"}}, "Property": "country"}}
                                            ],
                                            "Values": [[{"Literal": {"Value": "'United Kingdom'"}}]],
                                        }
                                    }
                                }
                            }
                        }
                    ],
                },
                "howCreated": "User",
            }
        ]
    }


def generate_report() -> None:
    page1_name = "a1b2c3d4e5f6a7b8c9d0"
    page2_name = "b1c2d3e4f5a6b7c8d9e0"

    page1_visuals = [
        textbox(
            "c0000000000000000001",
            24,
            16,
            900,
            48,
            [paragraph("Online Retail II  |  经营总览", 24, True)],
        ),
        textbox(
            "c0000000000000000002",
            24,
            60,
            1150,
            28,
            [paragraph("2009-12-01 — 2011-12-09  ·  SQL + Python 清洗后的商品销售与退货", 10)],
        ),
        card("c0000000000000000011", "净销售额", 24, 96, 280, 104),
        card("c0000000000000000012", "订单数", 324, 96, 280, 104),
        card("c0000000000000000013", "客户数", 624, 96, 280, 104),
        card("c0000000000000000014", "常规退货率", 924, 96, 280, 104),
        container(
            "c0000000000000000021",
            "lineChart",
            24,
            220,
            760,
            230,
            query_state={
                "Category": {
                    "projections": [
                        projection(column_field("DimDate", "year_month"), "DimDate.year_month", "月份")
                    ]
                },
                "Y": {
                    "projections": [
                        projection(measure_field("FactSales", "净销售额"), "FactSales.净销售额", "净销售额")
                    ]
                },
            },
            sort={"sort": [{"field": column_field("DimDate", "year_month"), "direction": "Ascending"}]},
            title="月度净销售额",
        ),
        container(
            "c0000000000000000022",
            "clusteredBarChart",
            800,
            220,
            456,
            230,
            query_state={
                "Category": {
                    "projections": [
                        projection(column_field("CountryTop", "country_cn"), "CountryTop.country_cn", "国家/地区")
                    ]
                },
                "Y": {
                    "projections": [
                        projection(measure_field("CountryTop", "净销售额"), "CountryTop.净销售额", "净销售额")
                    ]
                },
            },
            sort={"sort": [{"field": measure_field("CountryTop", "净销售额"), "direction": "Descending"}]},
            title="海外 Top 10 市场",
        ),
        container(
            "c0000000000000000023",
            "donutChart",
            24,
            466,
            360,
            220,
            query_state={
                "Category": {
                    "projections": [
                        projection(column_field("DimCustomer", "rfm_segment"), "DimCustomer.rfm_segment", "客群")
                    ]
                },
                "Y": {
                    "projections": [
                        projection(measure_field("FactSales", "净销售额"), "FactSales.净销售额", "净销售额")
                    ]
                },
            },
            title="RFM 客群营收（有客户 ID）",
        ),
        container(
            "c0000000000000000024",
            "lineChart",
            400,
            466,
            500,
            220,
            query_state={
                "Category": {
                    "projections": [
                        projection(column_field("DimDate", "year_month"), "DimDate.year_month", "月份")
                    ]
                },
                "Y": {
                    "projections": [
                        projection(measure_field("FactSales", "退货率"), "FactSales.退货率", "退货率"),
                        projection(measure_field("FactSales", "常规退货率"), "FactSales.常规退货率", "常规退货率"),
                    ]
                },
            },
            sort={"sort": [{"field": column_field("DimDate", "year_month"), "direction": "Ascending"}]},
            title="退货金额率",
        ),
        textbox(
            "c0000000000000000025",
            916,
            466,
            340,
            220,
            [
                paragraph("本页结论", 12, True),
                paragraph("11 月是销售峰值，完整月份平均为月均的 1.83 倍。", 9),
                paragraph("前 20% 客户贡献 76.7% 净销售额。", 9),
                paragraph("非英国市场同比 +15.3%，英国 +0.4%。", 9),
                paragraph("常规退货率 2.41%；两笔批量退货占退货额 34.1%。", 9),
            ],
        ),
    ]

    page2_visuals = [
        textbox(
            "d0000000000000000001",
            24,
            16,
            1000,
            48,
            [paragraph("客户与商品  |  RFM · 帕累托 · 留存 · Top SKU", 24, True)],
        ),
        textbox(
            "d0000000000000000002",
            24,
            60,
            1180,
            28,
            [paragraph("客群与商品表为 Python 预聚合结果；事实表与维度表支持在 Power BI 中切片和联动。", 10)],
        ),
        container(
            "d0000000000000000011",
            "tableEx",
            24,
            96,
            410,
            250,
            query_state={
                "Values": {
                    "projections": [
                        projection(column_field("RfmSummary", "rfm_segment"), "RfmSummary.rfm_segment", "客群"),
                        projection(column_field("RfmSummary", "customers"), "RfmSummary.customers", "客户数"),
                        projection(column_field("RfmSummary", "net_sales"), "RfmSummary.net_sales", "净销售额"),
                        projection(column_field("RfmSummary", "revenue_share"), "RfmSummary.revenue_share", "营收占比"),
                    ]
                }
            },
            title="RFM 客群结构",
            objects={"values": [{"properties": {"fontSize": literal("9D")}}]},
        ),
        container(
            "d0000000000000000012",
            "lineChart",
            450,
            96,
            400,
            250,
            query_state={
                "Category": {
                    "projections": [
                        projection(column_field("CustomerPareto", "customer_pct"), "CustomerPareto.customer_pct", "客户累计占比")
                    ]
                },
                "Y": {
                    "projections": [
                        projection(column_field("CustomerPareto", "cum_share"), "CustomerPareto.cum_share", "营收累计占比")
                    ]
                },
            },
            title="客户帕累托曲线",
        ),
        container(
            "d0000000000000000013",
            "matrix",
            866,
            96,
            390,
            250,
            query_state={
                "Rows": {
                    "projections": [
                        projection(column_field("Cohort", "cohort_month"), "Cohort.cohort_month", "首购月")
                    ]
                },
                "Columns": {
                    "projections": [
                        projection(column_field("Cohort", "period_label"), "Cohort.period_label", "首购后月数")
                    ]
                },
                "Values": {
                    "projections": [
                        projection(
                            aggregation_field("Cohort", "retention", 1),
                            "Cohort.retention",
                            "留存率",
                        )
                    ]
                },
            },
            title="月度客户留存",
            objects={"values": [{"properties": {"fontSize": literal("8D")}}]},
        ),
        container(
            "d0000000000000000021",
            "tableEx",
            24,
            362,
            700,
            330,
            query_state={
                "Values": {
                    "projections": [
                        projection(column_field("ProductTop", "description"), "ProductTop.description", "商品"),
                        projection(column_field("ProductTop", "stock_code"), "ProductTop.stock_code", "SKU"),
                        projection(column_field("ProductTop", "net_sales"), "ProductTop.net_sales", "净销售额"),
                        projection(column_field("ProductTop", "units_sold"), "ProductTop.units_sold", "销量"),
                        projection(column_field("ProductTop", "return_rate_value"), "ProductTop.return_rate_value", "退货率"),
                        projection(column_field("ProductTop", "abc_class"), "ProductTop.abc_class", "ABC"),
                    ]
                }
            },
            sort={"sort": [{"field": column_field("ProductTop", "net_sales"), "direction": "Descending"}]},
            title="Top 商品",
            objects={"values": [{"properties": {"fontSize": literal("9D")}}]},
        ),
        container(
            "d0000000000000000022",
            "tableEx",
            740,
            362,
            516,
            330,
            query_state={
                "Values": {
                    "projections": [
                        projection(column_field("ReturnInvoices", "invoice"), "ReturnInvoices.invoice", "发票"),
                        projection(column_field("ReturnInvoices", "invoice_date"), "ReturnInvoices.invoice_date", "日期"),
                        projection(column_field("ReturnInvoices", "description_filled"), "ReturnInvoices.description_filled", "商品"),
                        projection(column_field("ReturnInvoices", "return_amount"), "ReturnInvoices.return_amount", "退货金额"),
                    ]
                }
            },
            sort={"sort": [{"field": column_field("ReturnInvoices", "return_amount"), "direction": "Descending"}]},
            title="退货金额 drill-down",
            objects={"values": [{"properties": {"fontSize": literal("9D")}}]},
        ),
    ]

    pages = [
        {
            "name": page1_name,
            "displayName": "01 经营总览",
            "displayOption": "FitToPage",
            "height": 720,
            "width": 1280,
            "filterConfig": {"filters": []},
            "visuals": page1_visuals,
        },
        {
            "name": page2_name,
            "displayName": "02 客户与商品",
            "displayOption": "FitToPage",
            "height": 720,
            "width": 1280,
            "filterConfig": {"filters": []},
            "visuals": page2_visuals,
        },
    ]

    for page in pages:
        page_dir = REPORT_DIR / "definition" / "pages" / page["name"]
        page_dir.mkdir(parents=True, exist_ok=True)
        write_json(
            page_dir / "page.json",
            {
                "$schema": PAGE_SCHEMA,
                "name": page["name"],
                "displayName": page["displayName"],
                "displayOption": page["displayOption"],
                "height": page["height"],
                "width": page["width"],
                "filterConfig": page["filterConfig"],
            },
        )
        for visual in page["visuals"]:
            write_json(page_dir / "visuals" / visual["name"] / "visual.json", visual)

    write_json(
        REPORT_DIR / "definition" / "pages" / "pages.json",
        {
            "$schema": "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/pagesMetadata/1.0.0/schema.json",
            "pageOrder": [page["name"] for page in pages],
            "activePageName": page1_name,
        },
    )
    write_json(
        REPORT_DIR / "definition" / "version.json",
        {
            "$schema": "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/versionMetadata/1.0.0/schema.json",
            "version": "2.0.0",
        },
    )
    write_json(
        REPORT_DIR / "definition" / "report.json",
        {
            "$schema": REPORT_SCHEMA,
            "themeCollection": {
                "customTheme": {
                    "name": "OnlineRetail",
                    "type": "RegisteredResources",
                    "reportVersionAtImport": {"visual": "1.8.71", "report": "2.0.71", "page": "1.3.71"},
                }
            },
            "resourcePackages": [
                {
                    "name": "RegisteredResources",
                    "type": "RegisteredResources",
                    "items": [
                        {"name": "OnlineRetail", "path": "OnlineRetailTheme.json", "type": "CustomTheme"}
                    ],
                }
            ],
            "settings": {
                "useStylableVisualContainerHeader": True,
                "defaultDrillFilterOtherVisuals": True,
                "allowChangeFilterTypes": True,
                "useEnhancedTooltips": True,
            },
            "objects": {
                "section": [
                    {"properties": {"verticalAlignment": literal("'Top'")}}
                ],
                "outspacePane": [
                    {"properties": {"expanded": literal("false")}}
                ],
            },
        },
    )
    write_json(
        REPORT_DIR / "definition.pbir",
        {
            "$schema": "https://developer.microsoft.com/json-schemas/fabric/item/report/definitionProperties/2.0.0/schema.json",
            "version": "4.0",
            "datasetReference": {"byPath": {"path": "../OnlineRetailII.SemanticModel"}},
        },
    )
    write_json(
        REPORT_DIR / ".platform",
        {
            "$schema": "https://developer.microsoft.com/json-schemas/fabric/gitIntegration/platformProperties/2.0.0/schema.json",
            "metadata": {"type": "Report", "displayName": "OnlineRetailII"},
            "config": {"version": "2.0", "logicalId": stable_id("report_logical")},
        },
    )
    write_json(
        PBI_ROOT / "OnlineRetailII.pbip",
        {
            "version": "1.0",
            "artifacts": [{"report": {"path": "OnlineRetailII.Report"}}],
            "settings": {"enableAutoRecovery": True},
        },
    )

    theme = {
        "name": "OnlineRetail",
        "dataColors": [
            "#0F4C5C",
            "#E36414",
            "#2A9D8F",
            "#E9C46A",
            "#1D3557",
            "#A8DADC",
            "#C58B2A",
            "#8A9A9D",
        ],
        "background": "#FFFFFF",
        "foreground": "#21383D",
        "tableAccent": "#0F4C5C",
        "good": "#2A9D8F",
        "neutral": "#E9C46A",
        "bad": "#E36414",
        "maximum": "#0F4C5C",
        "minimum": "#F4EBD0",
        "textClasses": {
            "callout": {"fontSize": 24, "fontFace": "Microsoft YaHei", "color": "#1D3557"},
            "title": {"fontSize": 12, "fontFace": "Microsoft YaHei", "color": "#1D3557"},
            "header": {"fontSize": 10, "fontFace": "Microsoft YaHei", "color": "#21383D"},
            "label": {"fontSize": 9, "fontFace": "Microsoft YaHei", "color": "#5A6B70"},
        },
        "visualStyles": {},
    }
    write_json(REPORT_DIR / "StaticResources" / "RegisteredResources" / "OnlineRetailTheme.json", theme)


def main() -> None:
    prepare_parquet_outputs()
    generate_tmdl()
    generate_report()
    print(f"Generated PBIP at {PBI_ROOT}")


if __name__ == "__main__":
    main()
