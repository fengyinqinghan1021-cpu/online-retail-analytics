"""Validate PBIP JSON against Microsoft schemas and cross-check model references."""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

import requests
from jsonschema import Draft7Validator, RefResolver


ROOT = Path(__file__).resolve().parents[1]
PBI_ROOT = ROOT / "powerbi" / "OnlineRetailII"
REPORT = PBI_ROOT / "OnlineRetailII.Report"
MODEL = PBI_ROOT / "OnlineRetailII.SemanticModel"

_SCHEMA_CACHE: dict[str, dict] = {}


def fetch_schema(uri: str) -> dict:
    canonical_uri = uri.replace("schema.embedded.json", "schema-embedded.json")
    if canonical_uri not in _SCHEMA_CACHE:
        response = requests.get(canonical_uri, timeout=30)
        response.raise_for_status()
        _SCHEMA_CACHE[canonical_uri] = response.json()
    _SCHEMA_CACHE[uri] = _SCHEMA_CACHE[canonical_uri]
    return _SCHEMA_CACHE[uri]


def validate_file(path: Path, schema_uri: str) -> None:
    schema = fetch_schema(schema_uri)
    resolver = RefResolver(base_uri=schema_uri, referrer=schema, handlers={"http": fetch_schema, "https": fetch_schema})
    instance = json.loads(path.read_text(encoding="utf-8"))
    errors = sorted(Draft7Validator(schema, resolver=resolver).iter_errors(instance), key=lambda error: error.path)
    if errors:
        print(f"FAIL {path.relative_to(ROOT)}")
        for error in errors[:12]:
            print(f"  - {list(error.path)}: {error.message}")
        raise SystemExit(1)
    print(f"OK   {path.relative_to(ROOT)}")


def parse_model_references() -> tuple[set[str], set[str]]:
    entities: set[str] = set()
    fields: set[str] = set()
    for path in (MODEL / "definition" / "tables").glob("*.tmdl"):
        text = path.read_text(encoding="utf-8")
        table_match = re.search(r"^table\s+(.+)$", text, re.MULTILINE)
        if not table_match:
            continue
        table = table_match.group(1).strip().strip("'")
        entities.add(table)
        for column in re.findall(r"^\tcolumn\s+(.+)$", text, re.MULTILINE):
            fields.add(f"{table}.{column.strip().strip(chr(39))}")
        for measure in re.findall(r"^\tmeasure\s+'([^']+)'", text, re.MULTILINE):
            fields.add(f"{table}.{measure}")
    return entities, fields


def walk_query_refs(node, refs: set[str]) -> None:
    if isinstance(node, dict):
        if isinstance(node.get("queryRef"), str):
            refs.add(node["queryRef"])
        for value in node.values():
            walk_query_refs(value, refs)
    elif isinstance(node, list):
        for value in node:
            walk_query_refs(value, refs)


def main() -> None:
    if not (PBI_ROOT / "OnlineRetailII.pbip").exists():
        raise SystemExit("PBIP entry file missing")

    validate_file(
        REPORT / "definition" / "report.json",
        "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/report/3.0.0/schema.json",
    )
    validate_file(
        REPORT / "definition" / "version.json",
        "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/versionMetadata/1.0.0/schema.json",
    )
    validate_file(
        REPORT / "definition" / "pages" / "pages.json",
        "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/pagesMetadata/1.0.0/schema.json",
    )
    for page_path in sorted((REPORT / "definition" / "pages").glob("*/page.json")):
        validate_file(
            page_path,
            "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/page/2.0.0/schema.json",
        )
    for visual_path in sorted((REPORT / "definition" / "pages").glob("*/visuals/*/visual.json")):
        validate_file(
            visual_path,
            "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/visualContainer/2.3.0/schema.json",
        )

    entities, fields = parse_model_references()
    refs: set[str] = set()
    for visual_path in (REPORT / "definition" / "pages").glob("*/visuals/*/visual.json"):
        walk_query_refs(json.loads(visual_path.read_text(encoding="utf-8")), refs)

    missing: list[str] = []
    for ref in sorted(refs):
        entity, _, prop = ref.partition(".")
        if entity not in entities or ref not in fields:
            missing.append(ref)
    if missing:
        print("FAIL unresolved model references:")
        for ref in missing:
            print(f"  - {ref}")
        raise SystemExit(1)
    print(f"OK   {len(refs)} query references resolve to TMDL tables/columns/measures")

    data_path = re.search(
        r'expression DataPath = "([^"]+)"',
        (MODEL / "definition" / "expressions.tmdl").read_text(encoding="utf-8"),
    )
    if not data_path or not Path(data_path.group(1)).exists():
        raise SystemExit("DataPath parameter does not point to an existing folder")
    print(f"OK   DataPath exists: {data_path.group(1)}")

    theme_path = REPORT / "StaticResources" / "RegisteredResources" / "OnlineRetailTheme.json"
    json.loads(theme_path.read_text(encoding="utf-8"))
    print("OK   custom theme JSON parses")

    print("PBIP validation completed.")


if __name__ == "__main__":
    main()
