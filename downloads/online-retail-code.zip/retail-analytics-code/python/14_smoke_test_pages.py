"""Serve docs/ locally and smoke-test the static site over HTTP."""

from __future__ import annotations

import functools
import http.server
import threading
import urllib.request
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DOCS = ROOT / "docs"


class QuietHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, format: str, *args: object) -> None:
        return


def main() -> None:
    handler = functools.partial(QuietHandler, directory=str(DOCS))
    server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    port = server.server_address[1]
    base = f"http://127.0.0.1:{port}"
    try:
        checks = [
            "/",
            "/assets/figures/01_monthly_revenue.png",
            "/assets/preview/excel_dashboard.png",
            "/downloads/online-retail-dashboard.xlsx",
            "/downloads/online-retail-report.pdf",
            "/downloads/online-retail-pbip.zip",
            "/downloads/online-retail-code.zip",
        ]
        for path in checks:
            with urllib.request.urlopen(base + path, timeout=15) as response:
                body = response.read()
                print(f"{response.status} {len(body):>9,} {path}")
                if response.status != 200:
                    raise SystemExit(f"Unexpected status for {path}")
        with urllib.request.urlopen(base + "/", timeout=15) as response:
            html = response.read().decode("utf-8")
        if "GitHub Pages 静态展示版" not in html:
            raise SystemExit("Pages ribbon missing")
        print("Smoke test passed.")
    finally:
        server.shutdown()
        server.server_close()


if __name__ == "__main__":
    main()
