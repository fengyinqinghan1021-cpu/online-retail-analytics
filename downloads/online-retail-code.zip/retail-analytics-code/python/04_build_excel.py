"""Build the Excel executive dashboard and supporting analysis sheets."""

from __future__ import annotations

import json
from pathlib import Path

import pandas as pd
import xlsxwriter
from xlsxwriter.utility import xl_col_to_name


ROOT = Path(__file__).resolve().parents[1]
PROCESSED = ROOT / "data" / "processed"
OUTPUTS = ROOT / "outputs"
OUT_FILE = OUTPUTS / "Online_Retail_II_商业分析看板.xlsx"

FONT = "Microsoft YaHei"
NAVY = "#1D3557"
TEAL = "#0F4C5C"
CORAL = "#E36414"
GREEN = "#2A9D8F"
SAND = "#F4EBD0"
LIGHT = "#F2F6F7"
MID = "#D8E0E3"
WHITE = "#FFFFFF"
DARK = "#21383D"
MUTED = "#5A6B70"


def load_data() -> dict[str, object]:
    kpi = json.loads((OUTPUTS / "kpi_summary.json").read_text(encoding="utf-8"))
    monthly = pd.read_csv(PROCESSED / "monthly_kpis.csv")
    monthly["month_label"] = pd.to_datetime(monthly["invoice_month"]).dt.strftime("%Y-%m")
    monthly["ma3"] = monthly["net_sales"].rolling(3, min_periods=1).mean()
    return {
        "kpi": kpi,
        "monthly": monthly,
        "country": pd.read_csv(PROCESSED / "country_metrics.csv"),
        "rfm": pd.read_csv(PROCESSED / "rfm_segments.csv"),
        "abc": pd.read_csv(PROCESSED / "abc_summary.csv"),
        "products": pd.read_csv(PROCESSED / "top_products.csv"),
        "returns": pd.read_csv(PROCESSED / "return_products.csv"),
        "return_invoices": pd.read_csv(PROCESSED / "return_invoices.csv"),
        "cohort": pd.read_csv(PROCESSED / "cohort_retention.csv"),
        "pareto": pd.read_csv(PROCESSED / "customer_pareto.csv"),
        "quality": pd.read_csv(PROCESSED / "data_quality_summary.csv"),
    }


def write_section(workbook, worksheet, row: int, col: int, text: str, width: int) -> None:
    fmt = workbook.add_format(
        {
            "bold": True,
            "font_name": FONT,
            "font_size": 13,
            "font_color": NAVY,
            "bottom": 2,
            "bottom_color": CORAL,
        }
    )
    worksheet.merge_range(row, col, row, col + width - 1, text, fmt)


def write_table(
    workbook,
    worksheet,
    start_row: int,
    start_col: int,
    headers: list[str],
    rows: list[list[object]],
    formats: list[dict],
    widths: list[int] | None = None,
) -> None:
    header_fmt = workbook.add_format(
        {
            "bold": True,
            "font_name": FONT,
            "font_size": 10,
            "font_color": WHITE,
            "bg_color": NAVY,
            "align": "center",
            "valign": "vcenter",
            "border": 1,
            "border_color": WHITE,
        }
    )
    body_formats = [
        workbook.add_format(
            {
                "font_name": FONT,
                "font_size": 10,
                "font_color": DARK,
                "border": 1,
                "border_color": "#E8EFF1",
                "valign": "vcenter",
                **fmt,
            }
        )
        for fmt in formats
    ]
    for index, header in enumerate(headers):
        worksheet.write(start_row, start_col + index, header, header_fmt)
    for row_index, row_values in enumerate(rows):
        for col_index, value in enumerate(row_values):
            worksheet.write(
                start_row + 1 + row_index,
                start_col + col_index,
                value,
                body_formats[col_index],
            )
    if widths:
        for index, width in enumerate(widths):
            worksheet.set_column(start_col + index, start_col + index, width)


def chart_title(text: str) -> dict:
    return {"name": text, "name_font": {"name": FONT, "size": 12, "bold": True, "color": DARK}}


def chart_common(
    chart, y_num_format: str = "£#,##0", legend: bool = True, x_interval: int | None = None
) -> None:
    chart.set_chartarea({"fill": {"color": WHITE}, "border": {"none": True}})
    chart.set_plotarea({"fill": {"color": WHITE}, "border": {"none": True}})
    chart.set_legend(
        {"position": "bottom", "font": {"name": FONT, "size": 9, "color": MUTED}}
        if legend
        else {"none": True}
    )
    x_axis = {
        "num_font": {"name": FONT, "size": 8, "color": MUTED},
        "line": {"color": MID},
        "major_tick_mark": "none",
    }
    if x_interval:
        x_axis["interval_unit"] = x_interval
    chart.set_x_axis(x_axis)
    chart.set_y_axis(
        {
            "num_font": {"name": FONT, "size": 8, "color": MUTED},
            "num_format": y_num_format,
            "line": {"none": True},
            "major_gridlines": {"visible": True, "line": {"color": "#E8EFF1"}},
            "major_tick_mark": "none",
        }
    )


def main() -> None:
    data = load_data()
    kpi = data["kpi"]
    monthly = data["monthly"]
    country = data["country"].sort_values("net_sales", ascending=False)
    rfm = data["rfm"].sort_values("revenue_share", ascending=False)
    abc = data["abc"].sort_values("abc_class")
    products = data["products"].sort_values("net_sales", ascending=False)
    returns = data["returns"].sort_values("returns_value", ascending=False)
    cohort = data["cohort"]

    workbook = xlsxwriter.Workbook(OUT_FILE, {"nan_inf_to_errors": True})
    workbook.set_properties(
        {
            "title": "Online Retail II 商业分析看板",
            "subject": "SQL + Python + Excel + Power BI 端到端分析",
            "author": "Codex",
            "company": "Portfolio Project",
            "comments": "数据源：UCI Online Retail II",
        }
    )

    title_fmt = workbook.add_format(
        {"font_name": FONT, "font_size": 26, "bold": True, "font_color": WHITE, "bg_color": NAVY,
         "align": "left", "valign": "vcenter", "indent": 1}
    )
    subtitle_fmt = workbook.add_format(
        {"font_name": FONT, "font_size": 10, "font_color": "#DCE7EA", "bg_color": NAVY,
         "align": "left", "valign": "vcenter", "indent": 1}
    )
    section_fmt = workbook.add_format(
        {"font_name": FONT, "font_size": 13, "bold": True, "font_color": NAVY,
         "bottom": 2, "bottom_color": CORAL}
    )
    note_fmt = workbook.add_format(
        {"font_name": FONT, "font_size": 9, "font_color": MUTED, "text_wrap": True, "valign": "top"}
    )
    body_fmt = workbook.add_format(
        {"font_name": FONT, "font_size": 10, "font_color": DARK, "text_wrap": True, "valign": "top"}
    )
    bold_fmt = workbook.add_format({"font_name": FONT, "font_size": 10, "bold": True, "font_color": DARK})
    link_fmt = workbook.add_format(
        {"font_name": FONT, "font_size": 10, "font_color": TEAL, "underline": 1, "bold": True}
    )

    # ------------------------------------------------------------------ cover
    cover = workbook.add_worksheet("项目首页")
    cover.hide_gridlines(2)
    cover.set_column("A:A", 3)
    cover.set_column("B:G", 18)
    cover.set_row(1, 10)
    cover.set_landscape()
    cover.fit_to_pages(1, 1)
    cover.set_margins(0.3, 0.3, 0.3, 0.3)
    cover.merge_range("B2:G5", "ONLINE RETAIL II", title_fmt)
    cover.merge_range(
        "B6:G6",
        "英国在线零售商 2009–2011 交易数据分析  |  SQL → Python → Excel / Power BI",
        subtitle_fmt,
    )
    cover.set_row(5, 30)
    cover.merge_range(
        "B8:G10",
        "用 106.7 万行公开交易数据，回答四个问题：钱从哪里来、客户是谁、增长在哪里、退货是否失控。",
        workbook.add_format(
            {"font_name": FONT, "font_size": 13, "font_color": DARK, "text_wrap": True,
             "valign": "vcenter", "bg_color": LIGHT, "border": 1, "border_color": MID, "indent": 1}
        ),
    )
    cover.set_row(7, 26)
    cover.set_row(8, 26)
    cover.set_row(9, 26)

    cards = [
        ("净销售额", f"£{kpi['net_sales']/1e6:.2f}M", "商品销售扣除退货"),
        ("订单数", f"{kpi['orders']:,}", "有效商品销售订单"),
        ("客户数", f"{kpi['customers']:,}", "有客户 ID 的客户"),
        ("常规退货率", f"{kpi['return_rate_excl_bulk']*100:.2f}%", "剔除两笔批量退货"),
        ("原始行数", f"{kpi['raw_rows']:,}", "两张年度表合并"),
        ("覆盖国家/地区", "43", "含英国与海外市场"),
    ]
    card_positions = [(12, 1, 2), (12, 3, 4), (12, 5, 6), (17, 1, 2), (17, 3, 4), (17, 5, 6)]
    for (label, value, note), (row, left, right) in zip(cards, card_positions):
        cover.merge_range(row, left, row, right, label, workbook.add_format(
            {"font_name": FONT, "font_size": 10, "font_color": MUTED, "align": "center"}
        ))
        cover.merge_range(row + 1, left, row + 2, right, value, workbook.add_format(
            {"font_name": FONT, "font_size": 22, "bold": True, "font_color": TEAL, "align": "center", "valign": "vcenter"}
        ))
        cover.merge_range(row + 3, left, row + 3, right, note, workbook.add_format(
            {"font_name": FONT, "font_size": 8, "font_color": MUTED, "align": "center"}
        ))

    cover.merge_range("B22:G22", "交付物导航", section_fmt)
    links = [
        ("管理看板", "internal:'管理看板'!A1", "一页看清营收、客户、市场与退货"),
        ("客户分析", "internal:'客户分析'!A1", "RFM 客群、帕累托与月度留存"),
        ("商品与退货", "internal:'商品与退货'!A1", "Top SKU、ABC 分层、退货 drill-down"),
        ("市场分析", "internal:'市场分析'!A1", "国家/地区营收、订单与同比"),
        ("业务结论", "internal:'业务结论'!A1", "5 条结论、证据与建议动作"),
        ("数据附表", "internal:'数据附表'!A1", "图表数据源与数据质量记录"),
        ("数据字典", "internal:'数据字典'!A1", "字段定义与清洗口径"),
    ]
    for index, (label, url, description) in enumerate(links):
        row = 23 + index
        cover.write_url(row, 1, url, link_fmt, label)
        cover.merge_range(row, 2, row, 6, description, body_fmt)

    cover.merge_range(
        "B32:G35",
        "数据源：UCI Machine Learning Repository — Online Retail II（公开数据集）\n"
        "时间范围：2009-12-01 至 2011-12-09  |  货币：英镑（£）  |  粒度：订单行\n"
        "说明：原始数据包含两张年度表，2010-12 有 9 天重叠；本报告仅删除跨表重复行。",
        note_fmt,
    )

    # ------------------------------------------------------------ data appendix
    appendix = workbook.add_worksheet("数据附表")
    appendix.hide_gridlines(2)
    appendix.set_column("A:A", 14)
    appendix.set_column("B:B", 16)
    appendix.set_column("C:C", 16)
    appendix.set_column("D:D", 12)
    appendix.set_column("E:E", 12)
    appendix.set_column("F:F", 14)
    appendix.set_column("G:G", 14)
    appendix.set_column("H:H", 14)
    appendix.set_column("I:I", 16)
    appendix.merge_range("A1:I1", "数据附表 · 图表数据源与数据质量", title_fmt)
    appendix.set_row(0, 34)

    write_section(workbook, appendix, 2, 0, "月度经营数据", 9)
    monthly_headers = ["月份", "净销售额", "3个月移动平均", "订单数", "客户数", "客单价", "退货金额", "退货率", "剔除批量退货率"]
    monthly_rows = [
        [
            row["month_label"],
            round(float(row["net_sales"]), 2),
            round(float(row["ma3"]), 2),
            int(row["orders"]),
            int(row["customers"]),
            round(float(row["aov"]), 2),
            round(float(row["returns_value"]), 2),
            float(row["return_rate_value"]),
            float(row["return_rate_excl_bulk"]),
        ]
        for _, row in monthly.iterrows()
    ]
    write_table(
        workbook, appendix, 3, 0, monthly_headers, monthly_rows,
        [
            {"align": "left"},
            {"num_format": "£#,##0"},
            {"num_format": "£#,##0"},
            {"num_format": "#,##0"},
            {"num_format": "#,##0"},
            {"num_format": "£#,##0"},
            {"num_format": "£#,##0"},
            {"num_format": "0.00%"},
            {"num_format": "0.00%"},
        ],
    )

    write_section(workbook, appendix, 31, 0, "Top 10 海外市场", 4)
    market_rows = [
        [row["country_cn"], round(float(row["net_sales"]), 2), round(float(row["yoy"]), 4) if pd.notna(row["yoy"]) else None]
        for _, row in country.loc[country["country"] != "United Kingdom"].head(10).iterrows()
    ]
    write_table(
        workbook, appendix, 32, 0, ["国家/地区", "净销售额", "同比"], market_rows,
        [{"align": "left"}, {"num_format": "£#,##0"}, {"num_format": "0.0%"}],
    )
    appendix.write(
        44, 0,
        "英国净销售额 £16.22M，占 85.5%；为便于比较，图表仅展示海外市场。",
        note_fmt,
    )

    write_section(workbook, appendix, 45, 0, "RFM 客群", 6)
    rfm_rows = [
        [
            row["rfm_segment"],
            int(row["customers"]),
            round(float(row["net_sales"]), 2),
            float(row["customer_share"]),
            float(row["revenue_share"]),
        ]
        for _, row in rfm.iterrows()
    ]
    write_table(
        workbook, appendix, 46, 0, ["客群", "客户数", "净销售额", "客户占比", "营收占比"],
        rfm_rows,
        [{"align": "left"}, {"num_format": "#,##0"}, {"num_format": "£#,##0"}, {"num_format": "0.0%"}, {"num_format": "0.0%"}],
    )

    write_section(workbook, appendix, 54, 0, "ABC 分层", 4)
    abc_rows = [
        [row["abc_class"], int(row["skus"]), float(row["revenue_share"])]
        for _, row in abc.iterrows()
    ]
    write_table(
        workbook, appendix, 55, 0, ["层级", "SKU 数", "营收占比"], abc_rows,
        [{"align": "left"}, {"num_format": "#,##0"}, {"num_format": "0.0%"}],
    )

    write_section(workbook, appendix, 60, 0, "Top 10 商品", 5)
    product_rows = [
        [
            row["description"],
            row["stock_code"],
            round(float(row["net_sales"]), 2),
            int(row["units_sold"]),
            round(float(row["return_rate_value"]), 4),
        ]
        for _, row in products.head(10).iterrows()
    ]
    write_table(
        workbook, appendix, 61, 0, ["商品", "SKU", "净销售额", "销量", "退货率"],
        product_rows,
        [{"align": "left"}, {"align": "center"}, {"num_format": "£#,##0"}, {"num_format": "#,##0"}, {"num_format": "0.0%"}],
    )

    write_section(workbook, appendix, 74, 0, "退货金额 Top 10", 4)
    return_rows = [
        [row["description"], row["stock_code"], round(float(row["returns_value"]), 2), round(float(row["return_rate_value"]), 4)]
        for _, row in returns.head(10).iterrows()
    ]
    write_table(
        workbook, appendix, 75, 0, ["商品", "SKU", "退货金额", "退货率"], return_rows,
        [{"align": "left"}, {"align": "center"}, {"num_format": "£#,##0"}, {"num_format": "0.0%"}],
    )

    write_section(workbook, appendix, 88, 0, "数据质量记录", 5)
    quality_rows = [
        [row["指标"], int(row["数值"]) if str(row["数值"]).isdigit() else row["数值"], row["说明"]]
        for _, row in data["quality"].iterrows()
    ]
    write_table(
        workbook, appendix, 89, 0, ["指标", "数值", "说明"], quality_rows,
        [{"align": "left"}, {"num_format": "#,##0"}, {"align": "left"}],
    )

    # -------------------------------------------------------------- dashboard
    dash = workbook.add_worksheet("管理看板")
    dash.hide_gridlines(2)
    dash.set_column("A:O", 11)
    dash.merge_range("A1:O2", "经营总览  |  Online Retail II", title_fmt)
    dash.set_row(0, 26)
    dash.set_row(1, 26)
    dash.merge_range(
        "A3:O3",
        "2009-12-01 — 2011-12-09  ·  净销售额、订单、客户与退货  ·  数据源：UCI 公开数据集",
        subtitle_fmt,
    )

    card_specs = [
        ("净销售额", f"£{kpi['net_sales']/1e6:.2f}M", "商品销售扣除退货", TEAL),
        ("有效订单", f"{kpi['orders']:,}", "按发票去重", NAVY),
        ("客户数", f"{kpi['customers']:,}", "有客户 ID", GREEN),
        ("客单价中位数", f"£{kpi['aov_median']:,.0f}", "抗极端值", "#C58B2A"),
        ("常规退货率", f"{kpi['return_rate_excl_bulk']*100:.2f}%", f"全部退货率 {kpi['return_rate_value']*100:.2f}%", CORAL),
    ]
    for index, (label, value, note, color) in enumerate(card_specs):
        left = index * 3
        right = left + 2
        label_fmt = workbook.add_format(
            {"font_name": FONT, "font_size": 9, "font_color": WHITE, "bg_color": color,
             "align": "left", "valign": "vcenter", "indent": 1}
        )
        value_fmt = workbook.add_format(
            {"font_name": FONT, "font_size": 21, "bold": True, "font_color": WHITE, "bg_color": color,
             "align": "left", "valign": "vcenter", "indent": 1}
        )
        note_fmt_card = workbook.add_format(
            {"font_name": FONT, "font_size": 8, "font_color": "#EAF2F4", "bg_color": color,
             "align": "left", "valign": "vcenter", "indent": 1}
        )
        dash.merge_range(4, left, 4, right, label, label_fmt)
        dash.merge_range(5, left, 6, right, value, value_fmt)
        dash.merge_range(7, left, 7, right, note, note_fmt_card)
    dash.set_row(4, 20)
    dash.set_row(5, 28)
    dash.set_row(6, 28)
    dash.set_row(7, 18)

    # Chart 1: monthly net sales + moving average.
    chart1 = workbook.add_chart({"type": "column"})
    chart1.add_series(
        {
            "name": "净销售额",
            "categories": "='数据附表'!$A$5:$A$29",
            "values": "='数据附表'!$B$5:$B$29",
            "fill": {"color": TEAL},
            "border": {"none": True},
            "gap": 35,
        }
    )
    line1 = workbook.add_chart({"type": "line"})
    line1.add_series(
        {
            "name": "3个月移动平均",
            "categories": "='数据附表'!$A$5:$A$29",
            "values": "='数据附表'!$C$5:$C$29",
            "line": {"color": CORAL, "width": 2.25},
            "marker": {"type": "none"},
        }
    )
    chart1.combine(line1)
    chart1.set_title(chart_title("月度净销售额趋势"))
    chart_common(chart1, x_interval=3)
    chart1.set_size({"width": 545, "height": 310})
    dash.insert_chart("A9", chart1, {"x_offset": 8, "y_offset": 6})

    # Chart 2: top markets.
    chart2 = workbook.add_chart({"type": "bar"})
    chart2.add_series(
        {
            "name": "净销售额",
            "categories": "='数据附表'!$A$34:$A$43",
            "values": "='数据附表'!$B$34:$B$43",
            "fill": {"color": TEAL},
            "border": {"none": True},
            "data_labels": {"value": True, "num_format": "£#,##0", "font": {"name": FONT, "size": 8, "color": MUTED}},
        }
    )
    chart2.set_title(chart_title("海外 Top 10 市场：法国 +54.9%"))
    chart_common(chart2)
    chart2.set_y_axis({"reverse": True, "num_font": {"name": FONT, "size": 9, "color": MUTED}, "line": {"none": True}})
    chart2.set_x_axis({"num_format": "£#,##0", "num_font": {"name": FONT, "size": 8, "color": MUTED}})
    chart2.set_size({"width": 540, "height": 310})
    dash.insert_chart("H9", chart2, {"x_offset": 8, "y_offset": 6})
    dash.merge_range(
        "H44:O44",
        "注：英国 £16.22M，占 85.5%，未在图中展示；2011-12 仅含 1–9 日且含单笔 £168K 批量退货。",
        workbook.add_format({"font_name": FONT, "font_size": 7.5, "font_color": MUTED, "valign": "vcenter"}),
    )

    # Chart 3: RFM segments.
    chart3 = workbook.add_chart({"type": "bar"})
    chart3.add_series(
        {
            "name": "营收占比",
            "categories": "='数据附表'!$A$48:$A$53",
            "values": "='数据附表'!$E$48:$E$53",
            "fill": {"color": CORAL},
            "border": {"none": True},
            "data_labels": {"value": True, "num_format": "0.0%", "font": {"name": FONT, "size": 8, "color": MUTED}},
        }
    )
    chart3.add_series(
        {
            "name": "客户数占比",
            "categories": "='数据附表'!$A$48:$A$53",
            "values": "='数据附表'!$D$48:$D$53",
            "fill": {"color": TEAL},
            "border": {"none": True},
        }
    )
    chart3.set_title(chart_title("RFM 客群：核心客户贡献 68.7%"))
    chart_common(chart3, "0%", legend=True)
    chart3.set_y_axis({"reverse": True, "num_font": {"name": FONT, "size": 9, "color": MUTED}, "line": {"none": True}})
    chart3.set_x_axis({"num_format": "0%", "num_font": {"name": FONT, "size": 8, "color": MUTED}})
    chart3.set_size({"width": 545, "height": 310})
    dash.insert_chart("A27", chart3, {"x_offset": 8, "y_offset": 6})

    # Chart 4: returns.
    chart4 = workbook.add_chart({"type": "line"})
    chart4.add_series(
        {
            "name": "全部退货率",
            "categories": "='数据附表'!$A$5:$A$29",
            "values": "='数据附表'!$H$5:$H$29",
            "line": {"color": CORAL, "width": 2.1},
            "marker": {"type": "circle", "size": 4, "fill": {"color": CORAL}, "border": {"none": True}},
        }
    )
    chart4.add_series(
        {
            "name": "剔除两笔批量退货",
            "categories": "='数据附表'!$A$5:$A$29",
            "values": "='数据附表'!$I$5:$I$29",
            "line": {"color": TEAL, "width": 2.0, "dash_type": "dash"},
            "marker": {"type": "none"},
        }
    )
    chart4.set_title(chart_title("退货金额率：常规退货约 2.4%"))
    chart_common(chart4, "0.0%", x_interval=3)
    chart4.set_size({"width": 540, "height": 310})
    dash.insert_chart("H27", chart4, {"x_offset": 8, "y_offset": 6})

    # Insight strip.
    dash.merge_range("A45:O45", "本页结论", workbook.add_format(
        {"font_name": FONT, "font_size": 12, "bold": True, "font_color": WHITE, "bg_color": NAVY, "indent": 1}
    ))
    insights = [
        "01  11 月是销售峰值：完整月份中 11 月净销售额平均比月均高 83%，备货、客服与仓配应在 9–10 月前置。",
        "02  客户高度集中：前 20% 客户贡献 76.7% 净销售额，前 1% 客户贡献 31.1%；核心客户以 21.5% 的人数贡献 68.7% 营收。",
        "03  海外是增量：非英国市场同比 +15.3%，英国仅 +0.4%；法国 +54.9%、德国 +10.5%、荷兰 +10.9%。",
        "04  退货需分层管理：全部退货率 3.65%，两笔批量退货占退货额 34.1%；剔除后常规退货率 2.41%。",
        "05  商品长尾明显：1,038 个 A 类 SKU 贡献 80% 营收；前 20% SKU 贡献 77.9%，后 2,430 个 SKU 仅贡献 5%。",
    ]
    for index, text in enumerate(insights):
        dash.merge_range(46 + index, 0, 46 + index, 14, text, workbook.add_format(
            {"font_name": FONT, "font_size": 9.5, "font_color": DARK, "text_wrap": True,
             "valign": "vcenter", "bg_color": LIGHT if index % 2 == 0 else WHITE, "indent": 1}
        ))
        dash.set_row(46 + index, 30)

    dash.set_landscape()
    dash.set_paper(9)
    dash.fit_to_pages(1, 1)
    dash.set_margins(0.25, 0.25, 0.3, 0.3)

    # --------------------------------------------------------- customer sheet
    customer = workbook.add_worksheet("客户分析")
    customer.hide_gridlines(2)
    customer.set_column("A:A", 16)
    customer.set_column("B:H", 14)
    customer.merge_range("A1:H1", "客户分析 · RFM、帕累托与留存", title_fmt)
    customer.set_row(0, 34)
    customer.merge_range(
        "A2:H2",
        "客户级分析仅覆盖有 Customer ID 的 5,852 位客户；缺失客户 ID 的订单仍计入整体营收。",
        note_fmt,
    )
    write_section(workbook, customer, 4, 0, "RFM 客群结构", 8)
    rfm_headers = ["客群", "客户数", "净销售额", "客户占比", "营收占比", "平均最近购买天数", "平均订单数", "平均净销售额"]
    rfm_rows = [
        [
            row["rfm_segment"], int(row["customers"]), round(float(row["net_sales"]), 2),
            float(row["customer_share"]), float(row["revenue_share"]),
            round(float(row["avg_recency_days"]), 1), round(float(row["avg_orders"]), 1),
            round(float(row["avg_net_sales"]), 1),
        ]
        for _, row in rfm.iterrows()
    ]
    write_table(
        workbook, customer, 5, 0, rfm_headers, rfm_rows,
        [{"align": "left"}, {"num_format": "#,##0"}, {"num_format": "£#,##0"},
         {"num_format": "0.0%"}, {"num_format": "0.0%"}, {"num_format": "#,##0"},
         {"num_format": "0.0"}, {"num_format": "£#,##0"}],
    )

    # Pareto chart on customer sheet.
    pareto = data["pareto"]
    customer.write(14, 0, "帕累托数据", bold_fmt)
    customer.write(15, 0, "客户累计占比", bold_fmt)
    customer.write(15, 1, "营收累计占比", bold_fmt)
    pareto_start = 16
    for index, (_, row) in enumerate(pareto.head(150).iterrows()):
        customer.write_number(pareto_start + index, 0, float(row["customer_pct"]), workbook.add_format({"num_format": "0.0%"}))
        customer.write_number(pareto_start + index, 1, float(row["cum_share"]), workbook.add_format({"num_format": "0.0%"}))
    pareto_end = pareto_start + min(len(pareto), 150) - 1
    chart_pareto = workbook.add_chart({"type": "line"})
    chart_pareto.add_series(
        {
            "name": "累计营收占比",
            "categories": f"='客户分析'!$A${pareto_start+1}:$A${pareto_end+1}",
            "values": f"='客户分析'!$B${pareto_start+1}:$B${pareto_end+1}",
            "line": {"color": CORAL, "width": 2.4},
            "marker": {"type": "none"},
        }
    )
    chart_pareto.set_title(chart_title("客户帕累托：前 20% 贡献 76.7% 营收"))
    chart_common(chart_pareto, "0%")
    chart_pareto.set_x_axis({"num_format": "0%", "num_font": {"name": FONT, "size": 8, "color": MUTED}})
    chart_pareto.set_y_axis({"num_format": "0%", "num_font": {"name": FONT, "size": 8, "color": MUTED}})
    chart_pareto.set_size({"width": 620, "height": 330})
    customer.insert_chart("D7", chart_pareto, {"x_offset": 6, "y_offset": 6})

    # Cohort matrix with color scale.
    cohort_pivot = cohort.pivot(index="cohort_month", columns="period_index", values="retention").iloc[:18, :12]
    cohort_start = 35
    customer.merge_range(cohort_start, 0, cohort_start, 12, "首购月留存率（完整月份 cohort）", section_fmt)
    customer.write(cohort_start + 1, 0, "首购月", bold_fmt)
    for offset in range(12):
        customer.write(cohort_start + 1, 1 + offset, f"M+{offset}", bold_fmt)
    for row_index, (cohort_month, values) in enumerate(cohort_pivot.iterrows()):
        customer.write(cohort_start + 2 + row_index, 0, pd.Timestamp(cohort_month).strftime("%Y-%m"))
        for col_index, value in enumerate(values):
            if pd.notna(value):
                customer.write_number(
                    cohort_start + 2 + row_index, 1 + col_index, float(value),
                    workbook.add_format({"num_format": "0%", "font_name": FONT, "font_size": 9}),
                )
    last_cohort_row = cohort_start + 1 + len(cohort_pivot)
    customer.conditional_format(
        cohort_start + 2, 1, last_cohort_row, 12,
        {"type": "3_color_scale", "min_color": "#F7FBFC", "mid_color": "#A8DADC", "max_color": TEAL},
    )

    # ------------------------------------------------------ product / returns
    product_sheet = workbook.add_worksheet("商品与退货")
    product_sheet.hide_gridlines(2)
    product_sheet.set_column("A:A", 38)
    product_sheet.set_column("B:C", 12)
    product_sheet.set_column("D:G", 14)
    product_sheet.set_column("I:J", 18)
    product_sheet.merge_range("A1:G1", "商品与退货 · SKU 表现、ABC 与 drill-down", title_fmt)
    product_sheet.set_row(0, 34)
    write_section(workbook, product_sheet, 3, 0, "Top 20 商品（按净销售额）", 7)
    product_headers = ["商品", "SKU", "净销售额", "销量", "退货金额", "退货率", "ABC"]
    product_rows = [
        [
            row["description"], row["stock_code"], round(float(row["net_sales"]), 2),
            int(row["units_sold"]), round(float(row["returns_value"]), 2),
            round(float(row["return_rate_value"]), 4), row["abc_class"],
        ]
        for _, row in products.head(20).iterrows()
    ]
    write_table(
        workbook, product_sheet, 4, 0, product_headers, product_rows,
        [{"align": "left"}, {"align": "center"}, {"num_format": "£#,##0"},
         {"num_format": "#,##0"}, {"num_format": "£#,##0"}, {"num_format": "0.0%"},
         {"align": "center"}],
    )

    write_section(workbook, product_sheet, 28, 0, "退货金额 Top 15（含批量退货）", 4)
    return_headers = ["商品", "SKU", "退货金额", "退货率"]
    return_rows = [
        [row["description"], row["stock_code"], round(float(row["returns_value"]), 2), round(float(row["return_rate_value"]), 4)]
        for _, row in returns.head(15).iterrows()
    ]
    write_table(
        workbook, product_sheet, 29, 0, return_headers, return_rows,
        [{"align": "left"}, {"align": "center"}, {"num_format": "£#,##0"}, {"num_format": "0.0%"}],
    )
    product_sheet.merge_range(
        "I4:J12",
        "退货 drill-down\n\n"
        "两笔批量退货：\n"
        "C581484 · 2011-12-09 · £168,470\n"
        "C541433 · 2011-01-18 · £77,184\n\n"
        "合计占全部退货金额 34.1%。",
        workbook.add_format(
            {"font_name": FONT, "font_size": 9, "font_color": DARK, "bg_color": SAND,
             "border": 1, "border_color": "#E9D8A6", "text_wrap": True, "valign": "top", "indent": 1}
        ),
    )
    product_sheet.conditional_format(
        30, 3, 30 + len(return_rows) - 1, 3,
        {"type": "data_bar", "bar_color": CORAL, "bar_solid": True},
    )

    # ------------------------------------------------------------ market sheet
    market_sheet = workbook.add_worksheet("市场分析")
    market_sheet.hide_gridlines(2)
    market_sheet.set_column("A:A", 20)
    market_sheet.set_column("B:H", 14)
    market_sheet.merge_range("A1:H1", "市场分析 · 国家/地区表现与同比", title_fmt)
    market_sheet.set_row(0, 34)
    write_section(workbook, market_sheet, 3, 0, "国家/地区明细", 8)
    market_headers = ["国家/地区", "净销售额", "订单数", "客户数", "客单价", "退货率", "同比", "类型"]
    market_rows = [
        [
            row["country_cn"], round(float(row["net_sales"]), 2), int(row["orders"]),
            int(row["customers"]) if pd.notna(row["customers"]) else 0,
            round(float(row["aov"]), 2), round(float(row["return_rate_value"]), 4),
            round(float(row["yoy"]), 4) if pd.notna(row["yoy"]) else None,
            row["uk_flag"],
        ]
        for _, row in country.iterrows()
    ]
    write_table(
        workbook, market_sheet, 4, 0, market_headers, market_rows,
        [{"align": "left"}, {"num_format": "£#,##0"}, {"num_format": "#,##0"},
         {"num_format": "#,##0"}, {"num_format": "£#,##0"}, {"num_format": "0.0%"},
         {"num_format": "0.0%"}, {"align": "center"}],
    )
    market_sheet.freeze_panes(5, 0)
    market_sheet.autofilter(4, 0, 4 + len(market_rows), 7)
    market_sheet.conditional_format(
        5, 6, 4 + len(market_rows), 6,
        {"type": "3_color_scale", "min_color": "#F8D7DA", "mid_color": "#FFF3CD", "max_color": "#D4EDDA"},
    )
    market_sheet.merge_range(
        "A52:H55",
        "同比口径：2010-01-01 至 2010-12-09 vs 2011-01-01 至 2011-12-09，避免 12 月数据只到 9 日造成偏差。\n"
        "非英国市场同比 +15.3%，英国 +0.4%；爱尔兰的 -24.0% 主要由少数大客户订单波动驱动，不宜直接解读为市场需求下滑。",
        note_fmt,
    )

    # ----------------------------------------------------------- conclusions
    conclusion = workbook.add_worksheet("业务结论")
    conclusion.hide_gridlines(2)
    conclusion.set_landscape()
    conclusion.fit_to_pages(1, 1)
    conclusion.set_margins(0.3, 0.3, 0.3, 0.3)
    conclusion.set_column("A:A", 5)
    conclusion.set_column("B:B", 30)
    conclusion.set_column("C:C", 55)
    conclusion.set_column("D:D", 55)
    conclusion.merge_range("A1:D1", "5 条业务结论 · 证据与建议动作", title_fmt)
    conclusion.set_row(0, 36)
    conclusion.write_row(
        2, 0,
        ["#", "结论", "数据证据", "建议动作"],
        workbook.add_format({"font_name": FONT, "font_size": 10, "bold": True,
                             "font_color": WHITE, "bg_color": NAVY, "align": "center",
                             "border": 1, "border_color": WHITE}),
    )
    conclusions = [
        (
            "Q4 峰值明确，增长高度依赖 11 月",
            "在 2010–2011 的 22 个完整月份中，11 月净销售额平均为月均的 1.83 倍；2011-11 净销售额 £1.43M。",
            "将旺季备货、临时客服与仓配能力前置到 9–10 月；对 A 类 SKU 设置 11 月安全库存，避免缺货损失。",
        ),
        (
            "客户集中度高，核心客户是营收基本盘",
            "前 1% 客户贡献 31.1% 营收，前 20% 客户贡献 76.7%；RFM 核心客户仅占 21.5% 人数，却贡献 68.7% 营收。",
            "为核心客户建立专属客户经理与补货提醒；对流失预警客群（12.1% 人数、8.3% 营收）做召回，优先处理高历史价值客户。",
        ),
        (
            "海外市场是主要增量，英国增长接近饱和",
            "非英国市场同比 +15.3%，英国 +0.4%；法国 +54.9%、德国 +10.5%、荷兰 +10.9%；澳大利亚基数小但同比 +354%。",
            "优先深耕法国、德国、荷兰：本地化定价/运费、语言客服与重点品类测试；对澳大利亚先验证可持续复购，再加大投入。",
        ),
        (
            "退货整体可控，但被少数批量退货放大",
            "全部退货金额率 3.65%；两笔批量退货合计 £245.7K，占退货额 34.1%；剔除后常规退货率 2.41%。",
            "将批发取消/整单退货与消费者退货分开考核；对高退货金额商品做质检与包装复盘，对高退货率商品设置销售预警。",
        ),
        (
            "商品组合呈典型长尾，A 类 SKU 决定大盘",
            "1,038 个 A 类 SKU 贡献 80.0% 营收；前 20% SKU 贡献 77.9%；2,430 个 C 类 SKU 仅贡献 5.0%。",
            "A 类 SKU 保供、保曝光；B 类做组合销售与价格测试；C 类按动销与退货率逐步淘汰，释放库存与运营资源。",
        ),
    ]
    conclusion_title_fmt = workbook.add_format(
        {"font_name": FONT, "font_size": 11, "bold": True, "font_color": DARK,
         "text_wrap": True, "valign": "vcenter"}
    )
    conclusion_body_fmt = workbook.add_format(
        {"font_name": FONT, "font_size": 9.5, "font_color": DARK,
         "text_wrap": True, "valign": "vcenter"}
    )
    for index, (title, evidence, action) in enumerate(conclusions):
        row = 3 + index * 3
        conclusion.write_number(row, 0, index + 1, workbook.add_format(
            {"font_name": FONT, "font_size": 18, "bold": True, "font_color": CORAL, "align": "center", "valign": "top"}
        ))
        conclusion.merge_range(row, 1, row + 2, 1, title, conclusion_title_fmt)
        conclusion.merge_range(row, 2, row + 2, 2, evidence, conclusion_body_fmt)
        conclusion.merge_range(row, 3, row + 2, 3, action, conclusion_body_fmt)
        for offset in range(3):
            conclusion.set_row(row + offset, 36)

    # -------------------------------------------------------------- dictionary
    dictionary = workbook.add_worksheet("数据字典")
    dictionary.hide_gridlines(2)
    dictionary.set_column("A:A", 22)
    dictionary.set_column("B:B", 18)
    dictionary.set_column("C:C", 60)
    dictionary.merge_range("A1:C1", "数据字典与口径说明", title_fmt)
    dictionary.set_row(0, 34)
    fields = [
        ("invoice", "文本", "发票号；C 开头表示取消/退货发票。"),
        ("stock_code", "文本", "SKU；统一大写，去除大小写重复。"),
        ("description", "文本", "商品描述；缺失值按 SKU 众数补全。"),
        ("quantity", "整数", "数量；负数表示退货/取消。"),
        ("invoice_date", "时间", "交易时间；用于月份、星期、小时分析。"),
        ("price", "小数", "单价（英镑）；<=0 的记录不进入商品销售。"),
        ("customer_id", "文本", "客户 ID；缺失表示游客/未识别客户。"),
        ("country", "文本", "客户所在国家/地区。"),
        ("sales_amount", "小数", "有效商品销售金额 = 数量 × 单价。"),
        ("return_amount", "小数", "退货金额 = |数量| × 单价。"),
        ("net_amount", "小数", "净销售额 = sales_amount - return_amount。"),
        ("is_product_sale", "布尔", "非取消、数量>0、单价>0、非运费/调整等特殊 SKU。"),
        ("is_product_return", "布尔", "取消发票或负数量，且单价>0、非特殊 SKU。"),
        ("is_special_code", "布尔", "POST、DOT、M、BANK CHARGES、AMAZONFEE 等非商品行。"),
        ("is_guest", "布尔", "customer_id 缺失。"),
        ("price_outlier", "布尔", "价格 > SKU 中位数 6 倍且 > £50；仅标记，不删除。"),
        ("rfm_segment", "文本", "按 R/F/M 打分后的客群标签。"),
        ("abc_class", "文本", "按净销售额累计占比划分 A(<=80%) / B(<=95%) / C。"),
    ]
    dictionary.write_row(
        2, 0, ["字段", "类型", "定义 / 清洗口径"],
        workbook.add_format({"font_name": FONT, "font_size": 10, "bold": True,
                             "font_color": WHITE, "bg_color": NAVY, "border": 1, "border_color": WHITE}),
    )
    for index, (name, dtype, definition) in enumerate(fields):
        dictionary.write(3 + index, 0, name, workbook.add_format({"font_name": "Consolas", "font_size": 9}))
        dictionary.write(3 + index, 1, dtype, workbook.add_format({"font_name": FONT, "font_size": 9}))
        dictionary.write(3 + index, 2, definition, note_fmt)
    dictionary.merge_range(
        "A23:C27",
        "清洗规则摘要：\n"
        "1. 两张年度表按完整业务字段识别跨表重复，仅删除 2010-12 重叠期的重复行，保留同表内重复记录。\n"
        "2. 特殊 SKU（运费、手工调整、银行费用、礼品券等）不进入商品销售/退货指标。\n"
        "3. 退货分析同时展示“全部退货率”和“剔除两笔批量退货后的常规退货率”，避免单笔批发取消扭曲判断。\n"
        "4. 客户级指标仅使用有 Customer ID 的销售行；整体营收包含游客订单。",
        note_fmt,
    )

    workbook.close()
    print(f"Wrote {OUT_FILE}")


if __name__ == "__main__":
    main()
