"""Validate the GitHub Pages static site, links, and download bundles."""

from __future__ import annotations

import re
import zipfile
from pathlib import Path
from urllib.parse import unquote


ROOT = Path(__file__).resolve().parents[1]
DOCS = ROOT / "docs"
LINK_PATTERN = re.compile(r'(?:href|src)="([^"]+)"')
MAX_BYTES = 100 * 1024 * 1024


def main() -> None:
    index = DOCS / "index.html"
    text = index.read_text(encoding="utf-8")
    if "C:\\" in text or "file:///" in text:
        raise SystemExit("Local filesystem path found in docs/index.html")

    checked = 0
    missing: list[str] = []
    for raw_link in LINK_PATTERN.findall(text):
        if raw_link.startswith(("http://", "https://", "#", "mailto:")):
            continue
        target = (DOCS / unquote(raw_link)).resolve()
        checked += 1
        if not target.exists():
            missing.append(raw_link)
    if missing:
        print("Missing links:")
        for link in missing:
            print(f"  - {link}")
        raise SystemExit(1)
    print(f"OK {checked} local links resolve")

    required = [
        "index.html",
        "README.md",
        ".nojekyll",
        "downloads/online-retail-dashboard.xlsx",
        "downloads/online-retail-report.pdf",
        "downloads/online-retail-pbip.zip",
        "downloads/online-retail-code.zip",
        "assets/preview/excel_dashboard.png",
    ]
    for name in required:
        if not (DOCS / name).exists():
            raise SystemExit(f"Missing required file: {name}")
    print(f"OK {len(required)} required files present")

    for path in DOCS.rglob("*"):
        if path.is_file() and path.stat().st_size >= MAX_BYTES:
            raise SystemExit(f"File exceeds GitHub 100 MB limit: {path}")
    print("OK all files under GitHub 100 MB limit")

    for bundle in (
        DOCS / "downloads" / "online-retail-pbip.zip",
        DOCS / "downloads" / "online-retail-code.zip",
        ROOT / "retail-analytics-github-pages.zip",
    ):
        with zipfile.ZipFile(bundle) as archive:
            bad = archive.testzip()
            if bad:
                raise SystemExit(f"Corrupt zip member {bad} in {bundle.name}")
            if bundle.name == "online-retail-pbip.zip":
                names = set(archive.namelist())
                for required_name in (
                    "OnlineRetailII/OnlineRetailII.pbip",
                    "OnlineRetailII/configure_powerbi.ps1",
                    "OnlineRetailII/data/processed/fact_sales.parquet",
                ):
                    if required_name not in names:
                        raise SystemExit(f"PBIP bundle missing {required_name}")
        print(f"OK zip: {bundle.relative_to(ROOT)} ({bundle.stat().st_size / 1_000_000:.1f} MB)")

    total = sum(path.stat().st_size for path in DOCS.rglob("*") if path.is_file())
    print(f"OK docs total: {total / 1_000_000:.1f} MB")
    print("GitHub Pages validation completed.")


if __name__ == "__main__":
    main()
