"""Run versioned SQL, save query outputs, and build the SQL extract layer."""

from __future__ import annotations

import argparse
import re
from pathlib import Path

import duckdb


ROOT = Path(__file__).resolve().parents[1]
DB_PATH = ROOT / "data" / "retail.duckdb"
RESULTS_DIR = ROOT / "data" / "query_results"
RAW_PARQUET = ROOT / "data" / "processed" / "raw_combined.parquet"
QUERY_MARKER = re.compile(r"^-- @query:\s*(\w+)\s*$", re.MULTILINE)


def split_queries(sql_text: str) -> list[tuple[str, str]]:
    matches = list(QUERY_MARKER.finditer(sql_text))
    queries: list[tuple[str, str]] = []
    for index, match in enumerate(matches):
        start = match.end()
        end = matches[index + 1].start() if index + 1 < len(matches) else len(sql_text)
        body = sql_text[start:end].strip().rstrip(";").strip()
        if body:
            queries.append((match.group(1), body))
    return queries


def run_named_queries(connection: duckdb.DuckDBPyConnection, path: Path) -> None:
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    for name, query in split_queries(path.read_text(encoding="utf-8")):
        frame = connection.execute(query).fetchdf()
        output = RESULTS_DIR / f"{name}.csv"
        frame.to_csv(output, index=False, encoding="utf-8-sig")
        print(f"[{name}] {len(frame):,} rows -> {output.name}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--full", action="store_true", help="Rebuild the SQL extract table.")
    args = parser.parse_args()

    connection = duckdb.connect(str(DB_PATH))
    parquet_path = str(RAW_PARQUET).replace("'", "''")
    connection.execute(
        f"CREATE OR REPLACE VIEW raw AS SELECT * FROM read_parquet('{parquet_path}')"
    )
    run_named_queries(connection, ROOT / "sql" / "01_profile_raw.sql")

    if args.full:
        connection.execute((ROOT / "sql" / "02_build_extract.sql").read_text(encoding="utf-8"))
        print("Built sql_extract.parquet")

    connection.close()


if __name__ == "__main__":
    main()
