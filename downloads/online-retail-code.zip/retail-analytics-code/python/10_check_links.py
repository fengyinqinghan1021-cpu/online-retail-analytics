"""Check local links referenced by the project landing page."""

from __future__ import annotations

import re
from pathlib import Path
from urllib.parse import unquote


ROOT = Path(__file__).resolve().parents[1]
INDEX = ROOT / "index.html"
PATTERN = re.compile(r'(?:href|src)="([^"]+)"')


def main() -> None:
    text = INDEX.read_text(encoding="utf-8")
    missing: list[str] = []
    checked = 0
    for raw_link in PATTERN.findall(text):
        if raw_link.startswith(("http://", "https://", "#", "mailto:")):
            continue
        link = unquote(raw_link)
        target = (ROOT / link).resolve()
        checked += 1
        if not target.exists():
            missing.append(raw_link)
    if missing:
        print("Missing local links:")
        for link in missing:
            print(f"  - {link}")
        raise SystemExit(1)
    print(f"OK {checked} local links resolve")


if __name__ == "__main__":
    main()
