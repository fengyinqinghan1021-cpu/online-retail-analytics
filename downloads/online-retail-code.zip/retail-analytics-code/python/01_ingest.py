"""Ingest the UCI Online Retail II workbook into a reproducible Parquet file."""

from __future__ import annotations

import json
import urllib.request
import zipfile
from pathlib import Path

import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
RAW_XLSX = ROOT / "data" / "raw" / "online_retail_II.xlsx"
RAW_ZIP = ROOT / "data" / "raw" / "online_retail_ii.zip"
SOURCE_URL = "https://archive.ics.uci.edu/static/public/502/online+retail+ii.zip"
OUT_DIR = ROOT / "data" / "processed"
OUT_DIR.mkdir(parents=True, exist_ok=True)


def normalize_identifier(value: object) -> str | None:
    """Return a consistent string key for mixed numeric/text identifiers."""
    if pd.isna(value):
        return None
    if isinstance(value, (int, float)) and float(value).is_integer():
        return str(int(value))
    text = str(value).strip()
    return text[:-2] if text.endswith(".0") else text


def main() -> None:
    if not RAW_XLSX.exists():
        RAW_XLSX.parent.mkdir(parents=True, exist_ok=True)
        if not RAW_ZIP.exists():
            print(f"Downloading {SOURCE_URL}")
            urllib.request.urlretrieve(SOURCE_URL, RAW_ZIP)
        with zipfile.ZipFile(RAW_ZIP) as archive:
            archive.extractall(RAW_XLSX.parent)

    workbook = pd.ExcelFile(RAW_XLSX)
    frames: list[pd.DataFrame] = []
    sheet_manifest: list[dict[str, object]] = []

    for sheet in workbook.sheet_names:
        frame = pd.read_excel(workbook, sheet_name=sheet)
        frame["source_sheet"] = sheet
        frames.append(frame)
        sheet_manifest.append(
            {
                "sheet": sheet,
                "rows": int(len(frame)),
                "columns": list(frame.columns),
            }
        )
        print(f"Read {sheet}: {len(frame):,} rows")

    combined = pd.concat(frames, ignore_index=True)
    combined.columns = [
        "invoice",
        "stock_code",
        "description",
        "quantity",
        "invoice_date",
        "price",
        "customer_id",
        "country",
        "source_sheet",
    ]
    for column in ("invoice", "stock_code"):
        combined[column] = combined[column].map(normalize_identifier)
    combined["customer_id"] = (
        pd.to_numeric(combined["customer_id"], errors="coerce")
        .astype("Int64")
        .astype("string")
    )
    combined["description"] = combined["description"].astype("string").str.strip()
    combined["country"] = combined["country"].astype("string").str.strip()
    combined["invoice_date"] = pd.to_datetime(combined["invoice_date"], errors="raise")
    combined["quantity"] = pd.to_numeric(combined["quantity"], errors="coerce").astype("Int64")
    combined["price"] = pd.to_numeric(combined["price"], errors="coerce")

    out_path = OUT_DIR / "raw_combined.parquet"
    combined.to_parquet(out_path, index=False)

    manifest = {
        "source_url": "https://archive.ics.uci.edu/dataset/502/online+retail+ii",
        "source_file": RAW_XLSX.name,
        "sheets": sheet_manifest,
        "total_rows": int(len(combined)),
        "output": str(out_path.relative_to(ROOT)),
    }
    (OUT_DIR / "ingest_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(f"Wrote {out_path} ({len(combined):,} rows)")


if __name__ == "__main__":
    main()
