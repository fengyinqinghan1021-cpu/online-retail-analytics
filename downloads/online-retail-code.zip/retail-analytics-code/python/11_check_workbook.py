"""Inspect the delivered Excel workbook for sheet and link integrity."""

from pathlib import Path

from openpyxl import load_workbook


ROOT = Path(__file__).resolve().parents[1]
WORKBOOK = ROOT / "outputs" / "Online_Retail_II_商业分析看板.xlsx"


def main() -> None:
    workbook = load_workbook(WORKBOOK, read_only=False, data_only=False)
    print("sheets:", " | ".join(workbook.sheetnames))
    for sheet in workbook.worksheets:
        links = [
            cell.hyperlink.target
            for row in sheet.iter_rows()
            for cell in row
            if cell.hyperlink is not None
        ]
        if links:
            print(f"{sheet.title}: {len(links)} hyperlinks")
    print(f"size={WORKBOOK.stat().st_size:,} bytes")


if __name__ == "__main__":
    main()
