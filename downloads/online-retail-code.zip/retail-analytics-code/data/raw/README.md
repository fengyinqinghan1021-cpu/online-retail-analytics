# Raw data

The pipeline downloads the public UCI **Online Retail II** workbook automatically if
`online_retail_II.xlsx` is not present:

<https://archive.ics.uci.edu/static/public/502/online+retail+ii.zip>

The workbook contains two sheets:

- `Year 2009-2010`
- `Year 2010-2011`

The sheets overlap from 2010-12-01 to 2010-12-09. The SQL layer removes only
cross-sheet duplicates in this overlap window.
