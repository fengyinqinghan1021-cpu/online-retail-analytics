# Online Retail II Power BI 工程包

1. 解压本文件。
2. 右键运行 `configure_powerbi.ps1`，把模型的 `DataPath` 指向包内 `data/processed`。
3. 用 Power BI Desktop 打开 `OnlineRetailII.pbip`。
4. 在 Power BI 中点击“刷新”。

要求：Power BI Desktop 2023 或更新版本；支持 `Parquet.Document` 与 PBIP/PBIR。
