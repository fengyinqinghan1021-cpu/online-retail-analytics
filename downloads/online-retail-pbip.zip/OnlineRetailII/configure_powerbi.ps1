$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$dataPath = (Join-Path $root "data\processed").Replace("\", "/")
$expression = Join-Path $root "OnlineRetailII.SemanticModel\definition\expressions.tmdl"
$content = [IO.File]::ReadAllText($expression)
$content = $content -replace '(?m)^expression DataPath = "[^"]*"', ('expression DataPath = "' + $dataPath + '"')
[IO.File]::WriteAllText($expression, $content, [Text.UTF8Encoding]::new($false))
Write-Host "DataPath -> $dataPath"
